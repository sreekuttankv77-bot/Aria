# AI Studio Personal v2

ChatGPT-style personal AI chat UI with Gemini, OpenAI and OpenRouter API-key support.

- Normal conversational chat
- Conversation context
- Coding and Android-app assistance through chat
- API key stored locally
- Mobile-first dark UI
- No backend required for personal use

Open `index.html` in a browser and add your API key under Settings.
