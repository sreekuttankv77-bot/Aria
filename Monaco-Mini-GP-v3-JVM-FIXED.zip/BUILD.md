# Monaco Mini GP v1 — Repaired Build Package

This package is structured as a real Android Gradle project.

Important:
- `settings.gradle.kts` is at the project root.
- `app/` is directly under the project root.
- `.github/workflows/build.yml` is included.
- The workflow uses JDK 17 and Gradle 8.10.2.
- The workflow also supports a repository containing this ZIP instead of an already-extracted project.

For the most reliable GitHub setup, extract the ZIP contents into the repository root so that
`settings.gradle.kts` and `app/` are visible at the top level.
