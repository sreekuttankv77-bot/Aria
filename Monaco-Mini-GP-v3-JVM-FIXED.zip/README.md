# Monaco Mini GP v1
Clean arcade-style offline Android racing game prototype.

Features:
- Landscape mobile UI
- Monaco-inspired winding street circuit
- Play button
- Touch left/right steering
- 3-lap prototype
- Minimal arcade HUD
- Offline/no network dependencies

This is a prototype, not a licensed Formula 1 product and does not include official F1/Monaco assets.
