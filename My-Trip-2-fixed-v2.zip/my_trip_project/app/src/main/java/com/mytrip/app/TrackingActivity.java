package com.mytrip.app;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.maplibre.android.MapLibre;
import org.maplibre.android.location.LocationComponent;
import org.maplibre.android.location.LocationComponentActivationOptions;
import org.maplibre.android.location.modes.CameraMode;
import org.maplibre.android.location.modes.RenderMode;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;

import java.util.Locale;

public class TrackingActivity extends AppCompatActivity {

    private MapView map;
    private TextView distance;
    private TextView speed;
    private TextView duration;
    private long start;
    private final Handler h = new Handler(Looper.getMainLooper());
    private BroadcastReceiver rx;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (duration != null) {
                long elapsed = System.currentTimeMillis() - start;
                long seconds = elapsed / 1000;
                long hours = seconds / 3600;
                long minutes = (seconds % 3600) / 60;
                long secs = seconds % 60;

                duration.setText(String.format(
                        Locale.getDefault(),
                        "%02d:%02d:%02d\nDuration",
                        hours, minutes, secs
                ));
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        MapLibre.getInstance(this);
        setContentView(R.layout.activity_tracking);

        map = findViewById(R.id.mapView);
        distance = findViewById(R.id.liveDistance);
        speed = findViewById(R.id.liveSpeed);
        duration = findViewById(R.id.liveDuration);

        findViewById(R.id.stopButton).setOnClickListener(v -> stop());

        start = TripStorage.current(this)
                .optLong("start", System.currentTimeMillis());

        map.onCreate(b);

        map.getMapAsync(m -> m.setStyle(
                "https://demotiles.maplibre.org/style.json",
                style -> enableLocation(m)
        ));

        rx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (i.getBooleanExtra("stopped", false)) {
                    finish();
                    return;
                }

                double km = i.getDoubleExtra("distance", 0);
                double sp = i.getDoubleExtra("speed", 0);
                start = i.getLongExtra("start", start);

                distance.setText(String.format(
                        Locale.getDefault(), "%.1f km\nDistance", km));

                speed.setText(String.format(
                        Locale.getDefault(), "%.0f km/h\nSpeed", sp));
            }
        };

        registerReceiver(
                rx,
                new IntentFilter(LocationTrackingService.ACTION),
                Context.RECEIVER_NOT_EXPORTED
        );

        h.post(tick);
    }

    private void enableLocation(@NonNull MapLibreMap mapLibreMap) {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        LocationComponent locationComponent =
                mapLibreMap.getLocationComponent();

        LocationComponentActivationOptions options =
                LocationComponentActivationOptions.builder(
                        this, mapLibreMap, mapLibreMap.getStyle()).build();

        locationComponent.activateLocationComponent(options);
        locationComponent.setLocationComponentEnabled(true);
        locationComponent.setCameraMode(CameraMode.TRACKING);
        locationComponent.setRenderMode(RenderMode.COMPASS);
    }

    private void stop() {
        Intent intent = new Intent(this, LocationTrackingService.class);
        intent.setAction("STOP");
        startService(intent);
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (map != null) map.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
    }

    @Override
    protected void onPause() {
        if (map != null) map.onPause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (map != null) map.onStop();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacks(tick);
        if (rx != null) unregisterReceiver(rx);
        if (map != null) map.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (map != null) map.onLowMemory();
    }
}
