# My Trip release rules
