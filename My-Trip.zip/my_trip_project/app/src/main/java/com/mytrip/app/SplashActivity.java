package com.mytrip.app;
import android.app.*;import android.content.*;import android.os.*;
public class SplashActivity extends Activity{
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_splash);new Handler(Looper.getMainLooper()).postDelayed(()->{startActivity(new Intent(this,MainActivity.class));finish();},2000);}
}
