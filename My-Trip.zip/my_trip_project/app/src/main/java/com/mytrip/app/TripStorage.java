package com.mytrip.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public final class TripStorage {
    private static final String PREF="my_trip_data";
    private static final String TRIPS="trips";
    private static final String CURRENT="current";
    private TripStorage() {}
    private static SharedPreferences p(Context c){ return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    public static JSONArray trips(Context c){ try { return new JSONArray(p(c).getString(TRIPS,"[]")); } catch(Exception e){ return new JSONArray(); } }
    public static void saveTrips(Context c, JSONArray a){ p(c).edit().putString(TRIPS,a.toString()).apply(); }
    public static void addTrip(Context c,long start,long end,double km,double avg,double max){
        try { JSONArray a=trips(c); JSONObject o=new JSONObject(); o.put("start",start); o.put("end",end); o.put("distance",km); o.put("avg",avg); o.put("max",max); a.put(o); saveTrips(c,a); } catch(Exception ignored){}
    }
    public static void saveCurrent(Context c,long start,double km,double avg,double max){
        try { JSONObject o=new JSONObject(); o.put("start",start); o.put("distance",km); o.put("avg",avg); o.put("max",max); p(c).edit().putString(CURRENT,o.toString()).apply(); }catch(Exception ignored){}
    }
    public static JSONObject current(Context c){ try{return new JSONObject(p(c).getString(CURRENT,"{}"));}catch(Exception e){return new JSONObject();} }
    public static void clearCurrent(Context c){p(c).edit().remove(CURRENT).apply();}
    public static double distanceFor(Context c, Calendar from, Calendar to){
        double total=0; JSONArray a=trips(c); for(int i=0;i<a.length();i++){try{JSONObject o=a.getJSONObject(i); long s=o.getLong("start"); if(s>=from.getTimeInMillis()&&s<to.getTimeInMillis()) total+=o.optDouble("distance",0);}catch(Exception ignored){}}
        return total;
    }
    public static int countFor(Context c, Calendar from, Calendar to){int n=0;JSONArray a=trips(c);for(int i=0;i<a.length();i++){try{long s=a.getJSONObject(i).getLong("start");if(s>=from.getTimeInMillis()&&s<to.getTimeInMillis())n++;}catch(Exception ignored){}}return n;}
    public static String formatDate(long t){return new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date(t));}
    public static String formatShort(long t){return new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date(t));}
}
