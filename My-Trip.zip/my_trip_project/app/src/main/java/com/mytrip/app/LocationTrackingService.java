package com.mytrip.app;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.location.*;import android.os.*;import androidx.core.app.ActivityCompat;import androidx.core.app.NotificationCompat;

public class LocationTrackingService extends Service implements LocationListener {
    public static final String ACTION="com.mytrip.app.LOCATION_UPDATE"; private LocationManager lm; private Location last; private long start; private double distance=0,maxSpeed=0; private double speedSum=0; private int speedCount=0;
    public int onStartCommand(Intent i,int flags,int id){ if(i!=null&&"STOP".equals(i.getAction())){stopTracking();return START_NOT_STICKY;} startTracking();return START_STICKY; }
    private void startTracking(){
        if(start==0){start=System.currentTimeMillis();TripStorage.saveCurrent(this,start,0,0,0);} createChannel();startForeground(42,notification("My Trip is tracking your journey"));
        lm=(LocationManager)getSystemService(LOCATION_SERVICE); if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
        try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000,5,this);}catch(Exception ignored){}
    }
    private Notification notification(String text){return new NotificationCompat.Builder(this,"tracking").setSmallIcon(com.mytrip.app.R.drawable.ic_my_trip).setContentTitle("My Trip").setContentText(text).setOngoing(true).build();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("tracking","Trip tracking",NotificationManager.IMPORTANCE_LOW));}
    public void onLocationChanged(Location l){if(last!=null){float d=last.distanceTo(l);if(d>1&&d<1000)distance+=d/1000.0;} if(l.hasSpeed()){double s=l.getSpeed()*3.6;if(s>=0){speedSum+=s;speedCount++;maxSpeed=Math.max(maxSpeed,s);}}last=l;TripStorage.saveCurrent(this,start,distance,speedCount==0?0:speedSum/speedCount,maxSpeed);sendBroadcast(new Intent(ACTION).putExtra("distance",distance).putExtra("speed",l.hasSpeed()?l.getSpeed()*3.6:0).putExtra("start",start));}
    private void stopTracking(){if(lm!=null)lm.removeUpdates(this);long end=System.currentTimeMillis();double avg=speedCount==0?0:speedSum/speedCount;TripStorage.addTrip(this,start,end,distance,avg,maxSpeed);TripStorage.clearCurrent(this);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();sendBroadcast(new Intent(ACTION).putExtra("stopped",true));}
    public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} public void onStatusChanged(String p,int s,Bundle e){} public android.os.IBinder onBind(Intent i){return null;}
}
