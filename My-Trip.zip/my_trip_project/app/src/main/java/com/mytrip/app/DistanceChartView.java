package com.mytrip.app;

import android.content.Context;import android.graphics.*;import android.util.AttributeSet;import android.view.View;import java.util.*;

public class DistanceChartView extends View {
    private double[] values=new double[31]; private Paint p=new Paint(1);
    public DistanceChartView(Context c,AttributeSet a){super(c,a); p.setTypeface(Typeface.create("sans",Typeface.NORMAL));}
    public void setValues(double[] v){values=v;invalidate();}
    protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); p.setColor(Color.rgb(35,52,66));p.setStrokeWidth(1);for(int i=1;i<4;i++)c.drawLine(20,h*i/4f,w-12,h*i/4f,p); double max=1;for(double v:values)max=Math.max(max,v);Path path=new Path();boolean first=true;for(int i=0;i<values.length;i++){float x=20+(w-32)*i/(float)(values.length-1);float y=h-24-(float)(values[i]/max)*(h-44);if(first){path.moveTo(x,y);first=false;}else path.lineTo(x,y);}p.setColor(Color.rgb(33,230,138));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);p.setTextSize(11);p.setColor(Color.rgb(145,164,181));c.drawText("1",18,h-6,p);c.drawText("15",w/2-6,h-6,p);c.drawText("31",w-28,h-6,p);}
}
