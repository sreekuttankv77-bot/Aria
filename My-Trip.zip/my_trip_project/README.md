# My Trip

My Trip is a privacy-first Android travel tracker. It includes a 2-second splash screen, dark dashboard, live GPS tracking, trip distance totals, trip history, monthly chart, and MapLibre/OpenStreetMap-compatible map rendering.

## Build

Use JDK 17 and Gradle 9.1.0. The included GitHub Actions workflow installs Gradle and builds the debug APK.

## Notes

- GPS tracking starts only after the user grants location permission and taps Start.
- A foreground service keeps tracking while the app is in the background.
- Trip totals are stored locally on the device.
- The map style used by the demo is `https://demotiles.maplibre.org/style.json`; replace it with a production style/tile provider for a production release.
