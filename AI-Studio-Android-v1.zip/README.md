# AI Studio Android

Real Android APK wrapper around the ChatGPT-style AI Studio interface.

Features:
- Gemini / OpenAI / OpenRouter API key support
- API key stored in WebView local storage
- Chat-style interface
- Android portrait app
- GitHub Actions builds a real debug APK

The API key is entered by the user inside Settings; it is not hard-coded into the APK.
