package com.mytrip.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.app.AlertDialog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {

    private TextView progressText;
    private ProgressBar progress;
    private DistanceChartView chart;
    private LinearLayout recent;

    private int green = 0xff21e68a;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        try {
            bindViews();
            setDate();
            refreshDashboard();
            setupButtons();
        } catch (Exception e) {
            // Keep the Home screen alive even if stored trip data is malformed.
            showSafeDashboard();
        }
    }

    private void bindViews() {
        progressText = findViewById(R.id.progressText);
        progress = findViewById(R.id.progressBar);
        chart = findViewById(R.id.chart);
        recent = findViewById(R.id.recentTrips);
    }

    private void setDate() {
        TextView date = findViewById(R.id.dateText);
        if (date != null) {
            date.setText(new SimpleDateFormat(
                    "dd MMM yyyy, EEEE",
                    Locale.getDefault()
            ).format(Calendar.getInstance().getTime()));
        }
    }

    private void setupButtons() {
        View start = findViewById(R.id.startButton);
        if (start != null) {
            start.setOnClickListener(v -> startTrip());
        }

        View trips = findViewById(R.id.navTrips);
        if (trips != null) {
            trips.setOnClickListener(v ->
                    startActivity(new Intent(this, TrackingActivity.class)));
            trips.setClickable(true);
        }

        View home = findViewById(R.id.navHome);
        if (home != null) {
            home.setOnClickListener(v -> {
                View scroll = findViewById(R.id.homeScroll);
                if (scroll != null) scroll.scrollTo(0, 0);
            });
            home.setClickable(true);
        }

        View stats = findViewById(R.id.navStats);
        if (stats != null) {
            stats.setOnClickListener(v -> showStatsDialog());
            stats.setClickable(true);
        }

        View more = findViewById(R.id.navMore);
        if (more != null) {
            more.setOnClickListener(v -> showMoreDialog());
            more.setClickable(true);
        }
    }

    private void showStatsDialog() {
        Calendar now = Calendar.getInstance();
        Calendar monthStart = (Calendar) now.clone();
        monthStart.set(Calendar.DAY_OF_MONTH, 1);
        monthStart.set(Calendar.HOUR_OF_DAY, 0);
        monthStart.set(Calendar.MINUTE, 0);
        monthStart.set(Calendar.SECOND, 0);
        monthStart.set(Calendar.MILLISECOND, 0);
        Calendar nextMonth = (Calendar) monthStart.clone();
        nextMonth.add(Calendar.MONTH, 1);
        double km = TripStorage.distanceFor(this, monthStart, nextMonth);
        int trips = TripStorage.countFor(this, monthStart, nextMonth);
        new AlertDialog.Builder(this)
                .setTitle("This Month")
                .setMessage(String.format(Locale.getDefault(),
                        "Distance: %.1f km\nTrips: %d", km, trips))
                .setPositiveButton("OK", null)
                .show();
    }

    private void showMoreDialog() {
        new AlertDialog.Builder(this)
                .setTitle("My Trip")
                .setItems(new String[]{"Refresh dashboard", "About"}, (dialog, which) -> {
                    if (which == 0) {
                        refreshDashboard();
                    } else {
                        new AlertDialog.Builder(this)
                                .setTitle("My Trip")
                                .setMessage("Track. Travel. Remember.\n\nYour trips are stored on this device.")
                                .setPositiveButton("OK", null)
                                .show();
                    }
                })
                .show();
    }

    private void refreshDashboard() {
        Calendar now = Calendar.getInstance();

        Calendar dayStart = (Calendar) now.clone();
        dayStart.set(Calendar.HOUR_OF_DAY, 0);
        dayStart.set(Calendar.MINUTE, 0);
        dayStart.set(Calendar.SECOND, 0);
        dayStart.set(Calendar.MILLISECOND, 0);

        Calendar tomorrow = (Calendar) dayStart.clone();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);

        Calendar weekStart = (Calendar) dayStart.clone();
        weekStart.add(Calendar.DAY_OF_MONTH, -6);

        Calendar monthStart = (Calendar) dayStart.clone();
        monthStart.set(Calendar.DAY_OF_MONTH, 1);

        Calendar nextMonth = (Calendar) monthStart.clone();
        nextMonth.add(Calendar.MONTH, 1);

        Calendar yearStart = (Calendar) dayStart.clone();
        yearStart.set(Calendar.DAY_OF_YEAR, 1);

        Calendar nextYear = (Calendar) yearStart.clone();
        nextYear.add(Calendar.YEAR, 1);

        double todayKm = TripStorage.distanceFor(this, dayStart, tomorrow);
        double weekKm = TripStorage.distanceFor(this, weekStart, tomorrow);
        double monthKm = TripStorage.distanceFor(this, monthStart, nextMonth);
        double yearKm = TripStorage.distanceFor(this, yearStart, nextYear);

        setCard(R.id.todayCard, "Today", todayKm,
                TripStorage.countFor(this, dayStart, tomorrow));
        setCard(R.id.weekCard, "This Week", weekKm,
                TripStorage.countFor(this, weekStart, tomorrow));
        setCard(R.id.monthCard, "This Month", monthKm,
                TripStorage.countFor(this, monthStart, nextMonth));
        setCard(R.id.yearCard, "This Year", yearKm,
                TripStorage.countFor(this, yearStart, nextYear));

        if (progressText != null) {
            progressText.setText(String.format(
                    Locale.getDefault(), "%.1f km", todayKm));
        }

        if (progress != null) {
            progress.setMax(100);
            progress.setProgress((int) Math.min(100, Math.max(0, todayKm)));
        }

        showRecentTrips();

        if (chart != null) {
            chart.setValues(monthValues(monthStart));
        }
    }

    private void setCard(int id, String title, double km, int count) {
        View card = findViewById(id);
        if (!(card instanceof LinearLayout)) return;

        TextView titleView = card.findViewById(R.id.cardTitle);
        TextView valueView = card.findViewById(R.id.cardValue);
        TextView subView = card.findViewById(R.id.cardSub);

        if (titleView != null) titleView.setText(title);
        if (valueView != null) {
            valueView.setText(String.format(
                    Locale.getDefault(), "%.1f km", km));
        }
        if (subView != null) subView.setText(count + " Trips");
    }

    private double[] monthValues(Calendar monthStart) {
        double[] values = new double[31];

        for (int i = 0; i < values.length; i++) {
            Calendar from = (Calendar) monthStart.clone();
            from.add(Calendar.DAY_OF_MONTH, i);

            if (from.get(Calendar.MONTH) != monthStart.get(Calendar.MONTH)) {
                break;
            }

            Calendar to = (Calendar) from.clone();
            to.add(Calendar.DAY_OF_MONTH, 1);

            values[i] = TripStorage.distanceFor(this, from, to);
        }

        return values;
    }

    private void showRecentTrips() {
        if (recent == null) return;

        recent.removeAllViews();

        JSONArray trips = TripStorage.trips(this);

        for (int i = trips.length() - 1;
             i >= 0 && i >= trips.length() - 6;
             i--) {

            try {
                JSONObject trip = trips.getJSONObject(i);

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(14, 14, 14, 14);
                row.setBackgroundColor(0xff101e2a);

                TextView info = new TextView(this);
                info.setText(
                        "Trip\n" +
                        TripStorage.formatShort(trip.getLong("start")) +
                        " – " +
                        TripStorage.formatShort(trip.getLong("end"))
                );
                info.setTextColor(0xfff5f8fa);
                info.setTextSize(14);
                info.setLayoutParams(new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                ));

                TextView km = new TextView(this);
                km.setText(String.format(
                        Locale.getDefault(),
                        "%.1f km",
                        trip.optDouble("distance", 0)
                ));
                km.setTextColor(green);
                km.setTextSize(16);
                km.setGravity(android.view.Gravity.CENTER_VERTICAL);

                row.addView(info);
                row.addView(km);
                recent.addView(row);

                android.widget.Space spacer = new android.widget.Space(this);
                spacer.setLayoutParams(new LinearLayout.LayoutParams(1, 8));
                recent.addView(spacer);

            } catch (Exception ignored) {
                // Ignore one damaged trip instead of crashing the Home screen.
            }
        }
    }

    private void showSafeDashboard() {
        try {
            if (progressText != null) progressText.setText("0.0 km");
            if (progress != null) {
                progress.setMax(100);
                progress.setProgress(0);
            }
            if (chart != null) chart.setValues(new double[31]);
            if (recent != null) recent.removeAllViews();
            setupButtons();
        } catch (Exception ignored) {
        }
    }

    private void startTrip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.POST_NOTIFICATIONS
                        },
                        77
                );
            } else {
                requestPermissions(
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        },
                        77
                );
            }
            return;
        }

        launchTracking();
    }

    private void launchTracking() {
        Intent service = new Intent(this, LocationTrackingService.class);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(service);
            } else {
                startService(service);
            }
            startActivity(new Intent(this, TrackingActivity.class));
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Unable to start trip")
                    .setMessage(e.getMessage() == null ? "Please check location permission and try again." : e.getMessage())
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 77) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                launchTracking();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Location permission required")
                        .setMessage("My Trip needs location access to measure distance, speed and travel time.")
                        .setPositiveButton("OK", null)
                        .show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (progressText != null) {
            try {
                refreshDashboard();
            } catch (Exception ignored) {
                showSafeDashboard();
            }
        }
    }
}
