package com.mytrip.app;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.location.LocationComponent;
import org.maplibre.android.location.LocationComponentActivationOptions;
import org.maplibre.android.location.modes.CameraMode;
import org.maplibre.android.location.modes.RenderMode;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.layers.LineLayer;
import org.maplibre.android.style.layers.PropertyFactory;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.LineString;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TrackingActivity extends AppCompatActivity {

    private static final String STYLE_URL = "https://tiles.openfreemap.org/styles/liberty";
    private static final String ROUTE_SOURCE = "mytrip-route-source";
    private static final String ROUTE_LAYER = "mytrip-route-layer";

    private MapView map;
    private MapLibreMap mapLibreMap;
    private TextView distance;
    private TextView speed;
    private TextView duration;
    private TextView routeInfo;
    private EditText destinationInput;
    private Button routeButton;
    private long start;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private BroadcastReceiver rx;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (duration != null) {
                long elapsed = System.currentTimeMillis() - start;
                long seconds = elapsed / 1000;
                long hours = seconds / 3600;
                long minutes = (seconds % 3600) / 60;
                long secs = seconds % 60;
                duration.setText(String.format(Locale.getDefault(),
                        "%02d:%02d:%02d\nDuration", hours, minutes, secs));
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        MapLibre.getInstance(this);
        setContentView(R.layout.activity_tracking);

        map = findViewById(R.id.mapView);
        distance = findViewById(R.id.liveDistance);
        speed = findViewById(R.id.liveSpeed);
        duration = findViewById(R.id.liveDuration);
        destinationInput = findViewById(R.id.destinationInput);
        routeButton = findViewById(R.id.routeButton);
        routeInfo = findViewById(R.id.routeInfo);

        findViewById(R.id.stopButton).setOnClickListener(v -> stop());
        routeButton.setOnClickListener(v -> findBestRoute());

        start = TripStorage.current(this).optLong("start", System.currentTimeMillis());

        map.onCreate(b);
        map.getMapAsync(m -> {
            mapLibreMap = m;
            m.setStyle(STYLE_URL, style -> enableLocation(m));
        });

        rx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (i.getBooleanExtra("stopped", false)) {
                    finish();
                    return;
                }
                double km = i.getDoubleExtra("distance", 0);
                double sp = i.getDoubleExtra("speed", 0);
                start = i.getLongExtra("start", start);
                distance.setText(String.format(Locale.getDefault(), "%.1f km\nDistance", km));
                speed.setText(String.format(Locale.getDefault(), "%.0f km/h\nSpeed", sp));
            }
        };

        registerReceiver(rx, new IntentFilter(LocationTrackingService.ACTION), Context.RECEIVER_NOT_EXPORTED);
        h.post(tick);
    }

    private void enableLocation(@NonNull MapLibreMap mapLibreMap) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return;

        LocationComponent locationComponent = mapLibreMap.getLocationComponent();
        LocationComponentActivationOptions options =
                LocationComponentActivationOptions.builder(this, mapLibreMap.getStyle()).build();
        locationComponent.activateLocationComponent(options);
        locationComponent.setLocationComponentEnabled(true);
        locationComponent.setCameraMode(CameraMode.TRACKING);
        locationComponent.setRenderMode(RenderMode.COMPASS);
    }

    private void findBestRoute() {
        String destination = destinationInput.getText().toString().trim();
        if (TextUtils.isEmpty(destination)) {
            destinationInput.setError("Enter a destination");
            return;
        }
        if (mapLibreMap == null || mapLibreMap.getStyle() == null) {
            Toast.makeText(this, "Map is still loading. Try again in a moment.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission is required.", Toast.LENGTH_SHORT).show();
            return;
        }

        routeButton.setEnabled(false);
        routeInfo.setText("Finding best route…");
        hideKeyboard();

        Location current = mapLibreMap.getLocationComponent().getLastKnownLocation();
        if (current == null) {
            routeButton.setEnabled(true);
            routeInfo.setText("Waiting for your current location…");
            return;
        }

        network.execute(() -> {
            try {
                String q = URLEncoder.encode(destination, "UTF-8");
                String geocodeUrl = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=" + q;
                String geoJson = httpGet(geocodeUrl);
                JSONArray places = new JSONArray(geoJson);
                if (places.length() == 0) throw new Exception("Destination not found");

                JSONObject place = places.getJSONObject(0);
                double destLat = place.getDouble("lat");
                double destLon = place.getDouble("lon");
                String displayName = place.optString("display_name", destination);

                String routeUrl = String.format(Locale.US,
                        "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=false&alternatives=true",
                        current.getLongitude(), current.getLatitude(), destLon, destLat);
                String routeJson = httpGet(routeUrl);
                JSONObject routeRoot = new JSONObject(routeJson);
                JSONArray routes = routeRoot.optJSONArray("routes");
                if (routes == null || routes.length() == 0) throw new Exception("No driving route found");

                JSONObject best = routes.getJSONObject(0);
                JSONObject geometry = best.getJSONObject("geometry");
                JSONArray coords = geometry.getJSONArray("coordinates");
                ArrayList<LatLng> points = new ArrayList<>();
                for (int i = 0; i < coords.length(); i++) {
                    JSONArray c = coords.getJSONArray(i);
                    points.add(new LatLng(c.getDouble(1), c.getDouble(0)));
                }

                double km = best.getDouble("distance") / 1000.0;
                long seconds = best.getLong("duration");
                String eta = formatDuration(seconds);

                runOnUiThread(() -> {
                    routeButton.setEnabled(true);
                    drawRoute(points);
                    routeInfo.setText(String.format(Locale.getDefault(),
                            "Best route • %.1f km • %s\n%s", km, eta, displayName));
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    routeButton.setEnabled(true);
                    routeInfo.setText("Could not find a route. Check the destination and try again.");
                    Toast.makeText(this, e.getMessage() == null ? "Route search failed" : e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private String httpGet(String urlString) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("User-Agent", "MyTrip-Personal-Android/1.0 (personal use)");
        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) throw new Exception("Network error");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
            if (code < 200 || code >= 300) throw new Exception("Server returned " + code);
            return result.toString();
        } finally {
            connection.disconnect();
        }
    }

    private String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        if (hours > 0) return String.format(Locale.getDefault(), "%dh %02dm", hours, minutes);
        return String.format(Locale.getDefault(), "%d min", Math.max(1, minutes));
    }

    private void drawRoute(List<LatLng> points) {
        if (mapLibreMap == null || mapLibreMap.getStyle() == null || points.isEmpty()) return;
        Style style = mapLibreMap.getStyle();
        GeoJsonSource source = (GeoJsonSource) style.getSource(ROUTE_SOURCE);
        LineString line = LineString.fromLngLats(pointsToLngLat(points));
        if (source == null) {
            source = new GeoJsonSource(ROUTE_SOURCE, Feature.fromGeometry(line));
            style.addSource(source);
            LineLayer layer = new LineLayer(ROUTE_LAYER, ROUTE_SOURCE);
            layer.setProperties(
                    PropertyFactory.lineColor("#21E68A"),
                    PropertyFactory.lineWidth(6f),
                    PropertyFactory.lineOpacity(0.9f)
            );
            style.addLayer(layer);
        } else {
            source.setGeoJson(Feature.fromGeometry(line));
        }

        LatLngBounds.Builder bounds = new LatLngBounds.Builder();
        for (LatLng point : points) bounds.include(point);
        mapLibreMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), 80), 900);
    }

    private List<org.maplibre.geojson.Point> pointsToLngLat(List<LatLng> points) {
        List<org.maplibre.geojson.Point> result = new ArrayList<>();
        for (LatLng p : points) result.add(org.maplibre.geojson.Point.fromLngLat(p.getLongitude(), p.getLatitude()));
        return result;
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(destinationInput.getWindowToken(), 0);
    }

    private void stop() {
        Intent intent = new Intent(this, LocationTrackingService.class);
        intent.setAction("STOP");
        startService(intent);
        finish();
    }

    @Override protected void onStart() { super.onStart(); if (map != null) map.onStart(); }
    @Override protected void onResume() { super.onResume(); if (map != null) map.onResume(); }
    @Override protected void onPause() { if (map != null) map.onPause(); super.onPause(); }
    @Override protected void onStop() { if (map != null) map.onStop(); super.onStop(); }

    @Override protected void onDestroy() {
        h.removeCallbacks(tick);
        network.shutdownNow();
        if (rx != null) unregisterReceiver(rx);
        if (map != null) map.onDestroy();
        super.onDestroy();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (map != null) map.onLowMemory();
    }
}
