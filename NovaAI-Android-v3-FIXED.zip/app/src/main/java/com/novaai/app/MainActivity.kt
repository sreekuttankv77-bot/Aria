package com.novaai.app

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private val prefs by lazy { getSharedPreferences("nova", MODE_PRIVATE) }
    private val messages = mutableListOf<Pair<String,String>>()
    private var model = "gpt-4o-mini"

    private val bg = Color.rgb(8,9,13)
    private val surface = Color.rgb(18,20,27)
    private val surface2 = Color.rgb(25,27,36)
    private val purple = Color.rgb(124,77,255)
    private val text = Color.rgb(247,247,251)
    private val muted = Color.rgb(155,156,170)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showChat()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float, color: Int = text): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() }

    private fun button(label: String, action: () -> Unit): TextView =
        tv(label, 14f).apply {
            gravity = Gravity.CENTER
            background = rounded(purple, 18f)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnClickListener { action() }
        }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(14), dp(10), dp(14), dp(8))
        }
        setContentView(root)
        return root
    }

    private fun header(title: String, back: Boolean = false): LinearLayout {
        val h = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(10))
        }
        if (back) {
            h.addView(tv("‹", 32f).apply {
                setOnClickListener { showChat() }
                setPadding(0,0,dp(16),0)
            }, LinearLayout.LayoutParams(dp(40), dp(52)))
        }
        h.addView(tv(title, 22f).apply {
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        h.addView(tv("⋮", 26f).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(36), dp(52)))
        return h
    }

    private fun showChat() {
        base()
        root.addView(header("Nova AI"))
        val modelBtn = tv("✦  $model ⌄", 14f).apply {
            gravity = Gravity.CENTER
            background = rounded(surface2, 20f)
            setPadding(dp(16),dp(9),dp(16),dp(9))
            setOnClickListener { showModels() }
        }
        root.addView(modelBtn, LinearLayout.LayoutParams(-1, dp(44)))
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        if (messages.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            empty.addView(tv("✦", 52f, Color.rgb(167,139,250)).apply { gravity = Gravity.CENTER })
            empty.addView(tv("How can I help?", 26f).apply { gravity = Gravity.CENTER; setTypeface(null,1) })
            empty.addView(tv("Ask anything. Use your own API key.", 14f, muted).apply { gravity = Gravity.CENTER })
            content.addView(empty, FrameLayout.LayoutParams(-1,-1))
        } else renderMessages()

        val inputRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val input = EditText(this).apply {
            hint = "Message Nova AI…"; setHintTextColor(muted); setTextColor(this@MainActivity.text)
            textSize = 15f; setSingleLine(false); maxLines = 4
            background = rounded(surface2, 24f)
            setPadding(dp(16),dp(10),dp(16),dp(10))
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, dp(56), 1f))
        val send = TextView(this).apply {
            text = "➤"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded(purple, 28f)
            setOnClickListener {
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) { input.setText(""); sendMessage(q) }
            }
        }
        inputRow.addView(send, LinearLayout.LayoutParams(dp(54),dp(54)).apply { leftMargin=dp(8) })
        root.addView(inputRow)

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0,dp(8),0,0)
        }
        nav.addView(navItem("⌂\nChat") { showChat() })
        nav.addView(navItem("◷\nHistory") { showHistory() })
        nav.addView(navItem("◉\nExplore") { showExplore() })
        nav.addView(navItem("⚙\nSettings") { showSettings() })
        root.addView(nav, LinearLayout.LayoutParams(-1,dp(60)))
    }

    private fun navItem(label: String, action: () -> Unit) =
        tv(label, 11f, muted).apply {
            gravity=Gravity.CENTER; setOnClickListener{action()}
        }.also { it.layoutParams = LinearLayout.LayoutParams(0,dp(58),1f) }

    private fun renderMessages() {
        content.removeAllViews()
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,dp(12),0,dp(12)) }
        for ((who,msg) in messages) {
            val card = tv(msg, 15f).apply {
                setPadding(dp(15),dp(12),dp(15),dp(12))
                background = rounded(if(who=="You") Color.rgb(55,39,102) else surface, 18f)
            }
            val p = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.setMargins(if(who=="You") dp(42) else 0, dp(7), if(who=="You") 0 else dp(12), dp(7))
            box.addView(card,p)
        }
        scroll.addView(box); content.addView(scroll,FrameLayout.LayoutParams(-1,-1))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage(q: String) {
        messages.add("You" to q); renderMessages()
        messages.add("Nova" to "Thinking…"); renderMessages()
        val key = prefs.getString("api_key","") ?: ""
        if (key.isBlank()) {
            messages[messages.lastIndex] = "Nova" to "Add your OpenAI API key in Settings → API Keys."
            renderMessages(); return
        }
        thread {
            val answer = try { callOpenAI(key,q) } catch(e:Exception) {
                "Connection error: ${e.message ?: "Unknown error"}"
            }
            runOnUiThread {
                messages[messages.lastIndex] = "Nova" to answer
                renderMessages()
            }
        }
    }

    private fun callOpenAI(key:String, prompt:String):String {
        val url = URL("https://api.openai.com/v1/chat/completions")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.connectTimeout=20000; c.readTimeout=60000
        c.setRequestProperty("Authorization","Bearer $key")
        c.setRequestProperty("Content-Type","application/json")
        c.doOutput=true
        val body=JSONObject().apply{
            put("model",model)
            put("messages",JSONArray().put(JSONObject().apply{
                put("role","user"); put("content",prompt)
            }))
        }
        OutputStreamWriter(c.outputStream).use{it.write(body.toString())}
        val stream = if(c.responseCode in 200..299)c.inputStream else c.errorStream
        val result=stream.bufferedReader().use{it.readText()}
        if(c.responseCode !in 200..299) throw Exception(JSONObject(result).optJSONObject("error")?.optString("message") ?: "HTTP ${c.responseCode}")
        return JSONObject(result).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
    }

    private fun showModels() {
        base(); root.addView(header("Select Model",true))
        val models = listOf("gpt-4o-mini","gpt-4o","gpt-4.1-mini","gpt-4.1","o4-mini")
        for(m in models) {
            val row=tv("OpenAI\n$m",15f).apply{
                background=rounded(surface,16f); setPadding(dp(16),dp(13),dp(16),dp(13))
                setOnClickListener{model=m;showChat()}
            }
            root.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{bottomMargin=dp(8)})
        }
    }

    private fun showHistory() {
        base(); root.addView(header("History",true))
        if(messages.isEmpty()) root.addView(tv("No conversations yet.",16f,muted).apply{setPadding(8,20,8,20)})
        else messages.filter{it.first=="You"}.reversed().forEach{
            root.addView(tv("• ${it.second}",15f).apply{background=rounded(surface,16f);setPadding(dp(16),dp(14),dp(16),dp(14))},
                LinearLayout.LayoutParams(-1,dp(58)).apply{bottomMargin=dp(8)})
        }
    }

    private fun showExplore() {
        base(); root.addView(header("Explore",true))
        val cards=listOf("Web Search" to "Search the web for current information","Image Generation" to "Create images from prompts","Document Analyzer" to "Analyze PDFs and text","Quick Prompts" to "Useful prompts for everyday tasks")
        for((a,b) in cards){
            root.addView(tv("$a\n$b",15f).apply{background=rounded(surface,18f);setPadding(dp(16),dp(14),dp(16),dp(14))},
                LinearLayout.LayoutParams(-1,dp(78)).apply{bottomMargin=dp(10)})
        }
    }

    private fun showSettings() {
        base(); root.addView(header("Settings",true))
        val api=tv("API Keys\nOpenAI • ${if((prefs.getString("api_key","")?:"").isBlank())"Not configured" else "Active"}",15f).apply{
            background=rounded(surface,18f);setPadding(dp(16),dp(15),dp(16),dp(15));setOnClickListener{showApiKey()}
        }
        root.addView(api,LinearLayout.LayoutParams(-1,dp(78)).apply{bottomMargin=dp(10)})
        root.addView(tv("Default Model\n$model",15f).apply{
            background=rounded(surface,18f);setPadding(dp(16),dp(15),dp(16),dp(15));setOnClickListener{showModels()}
        },LinearLayout.LayoutParams(-1,dp(78)).apply{bottomMargin=dp(10)})
        root.addView(tv("Appearance\nDark",15f).apply{
            background=rounded(surface,18f);setPadding(dp(16),dp(15),dp(16),dp(15))
        },LinearLayout.LayoutParams(-1,dp(78)))
        root.addView(tv("Nova AI\nPersonal AI client • Your keys stay on this device",13f,muted).apply{setPadding(dp(6),dp(28),dp(6),dp(6))})
    }

    private fun showApiKey() {
        base(); root.addView(header("API Keys",true))
        root.addView(tv("Your API key is stored locally on this device.",14f,muted).apply{setPadding(dp(6),0,dp(6),dp(16))})
        val input=EditText(this).apply{
            hint="sk-…"; setHintTextColor(muted);setTextColor(this@MainActivity.text);textSize=15f
            inputType=0x81; background=rounded(surface,18f);setPadding(dp(16),dp(14),dp(16),dp(14))
            setText(prefs.getString("api_key",""))
        }
        root.addView(input,LinearLayout.LayoutParams(-1,dp(58)).apply{bottomMargin=dp(14)})
        root.addView(button("Save API Key"){
            prefs.edit().putString("api_key",input.text.toString().trim()).apply()
            Toast.makeText(this,"API key saved locally",Toast.LENGTH_SHORT).show()
            showSettings()
        },LinearLayout.LayoutParams(-1,dp(54)))
    }
}
