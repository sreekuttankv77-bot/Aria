# Nova AI currently does not require custom ProGuard rules.
