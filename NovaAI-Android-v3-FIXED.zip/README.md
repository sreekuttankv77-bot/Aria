# Nova AI Android

A personal ChatGPT-style Android AI client.

## Features
- Dark ChatGPT-style UI
- OpenAI API key entered by the user
- API key stored locally in SharedPreferences
- Model selector
- Chat history view
- Explore screen
- Settings
- GitHub Actions APK build

## Build
Push this project to a GitHub repository. The included workflow builds a debug APK and uploads it as a workflow artifact.

## API key
Open **Settings → API Keys**, enter your own OpenAI API key, save it, then start chatting.

This project is intended as a personal client. Do not commit API keys into source code.
