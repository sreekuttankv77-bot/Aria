package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.HabitItem
import com.example.data.model.NoteItem
import com.example.data.model.Priority
import com.example.data.model.TaskCategory
import com.example.data.model.TaskItem
import com.example.data.model.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TaskItem::class, NoteItem::class, HabitItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun noteDao(): NoteDao
    abstract fun habitDao(): HabitDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "novahub_database"
                )
                .addCallback(DatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database)
                    }
                }
            }
        }

        suspend fun populateDatabase(database: AppDatabase) {
            val taskDao = database.taskDao()
            val noteDao = database.noteDao()
            val habitDao = database.habitDao()

            val sampleTasks = listOf(
                TaskItem(
                    title = "Refactor Navigation Pipeline",
                    description = "Implement fluid spring animations and gesture navigation for fluid screen shifts.",
                    category = TaskCategory.DEVELOPMENT.name,
                    priority = Priority.URGENT.name,
                    status = TaskStatus.IN_PROGRESS.name,
                    dueDate = "Today, 4:00 PM",
                    subtasksRaw = "Refactor AnimatedNavHost||Add Haptic Feedback||Benchmark 120Hz smooth scrolling",
                    estimatedMinutes = 45,
                    isPinned = true
                ),
                TaskItem(
                    title = "Design Material 3 Dark Palette",
                    description = "Fine-tune OLED deep blacks and vibrant neon cyan & violet accents.",
                    category = TaskCategory.DESIGN.name,
                    priority = Priority.HIGH.name,
                    status = TaskStatus.TODO.name,
                    dueDate = "Tomorrow, 11:00 AM",
                    subtasksRaw = "Generate high contrast swatches||Audit contrast ratios for WCAG AAA",
                    estimatedMinutes = 60,
                    isPinned = true
                ),
                TaskItem(
                    title = "Team Sprint Retrospective",
                    description = "Review weekly metrics, velocity achievements, and roadmap milestones.",
                    category = TaskCategory.WORK.name,
                    priority = Priority.MEDIUM.name,
                    status = TaskStatus.TODO.name,
                    dueDate = "Thursday, 2:30 PM",
                    subtasksRaw = "Compile slide deck||Collect asynchronous feedback",
                    estimatedMinutes = 30
                ),
                TaskItem(
                    title = "30-Min Cardio & Core Workout",
                    description = "Maintain daily streak with HIIT training and stretching session.",
                    category = TaskCategory.HEALTH.name,
                    priority = Priority.MEDIUM.name,
                    status = TaskStatus.COMPLETED.name,
                    isCompleted = true,
                    dueDate = "Today, 7:00 AM",
                    subtasksRaw = "Warm-up dynamic stretches||5x Interval sprints||Cool down & hydration",
                    estimatedMinutes = 30
                ),
                TaskItem(
                    title = "Review Cloud Infrastructure Budget",
                    description = "Audit compute clusters and optimize cache retention policies.",
                    category = TaskCategory.FINANCE.name,
                    priority = Priority.LOW.name,
                    status = TaskStatus.TODO.name,
                    dueDate = "Friday, 5:00 PM",
                    subtasksRaw = "Analyze billing breakdown||Right-size underutilized VMs",
                    estimatedMinutes = 20
                )
            )
            taskDao.insertTasks(sampleTasks)

            val sampleNotes = listOf(
                NoteItem(
                    title = "App Architecture & UX Principles",
                    content = "1. Instant feedback with spring physics on interactive surfaces.\n2. Deep contrast cards with subtle border illumination.\n3. Thumb-friendly bottom dock navigation.\n4. Zero dead-ends.",
                    tag = "Architecture",
                    colorHex = 0xFF6366F1,
                    isPinned = true
                ),
                NoteItem(
                    title = "Ideas for Nova Hub v2.0",
                    content = "• Offline-first SQLite fast caching\n• Micro-interactions with Compose canvas particle bursts\n• Voice quick-entry and natural language dates",
                    tag = "Roadmap",
                    colorHex = 0xFF06B6D4,
                    isPinned = true
                ),
                NoteItem(
                    title = "Daily Focus Routine",
                    content = "Pomodoro: 45 min deep work + 10 min break. Hydrate before every sprint block. Clear notifications in batch mode.",
                    tag = "Habits",
                    colorHex = 0xFF10B981,
                    isPinned = false
                )
            )
            noteDao.insertNotes(sampleNotes)

            val sampleHabits = listOf(
                HabitItem(name = "Morning Hydration (1L)", streak = 14, isCompletedToday = true, icon = "water_drop", colorHex = 0xFF06B6D4),
                HabitItem(name = "Deep Focus (90 mins)", streak = 8, isCompletedToday = true, icon = "psychology", colorHex = 0xFF6366F1),
                HabitItem(name = "Read Tech Documentation", streak = 5, isCompletedToday = false, icon = "menu_book", colorHex = 0xFFF59E0B),
                HabitItem(name = "Evening Walk (5,000 steps)", streak = 12, isCompletedToday = false, icon = "directions_walk", colorHex = 0xFF10B981)
            )
            habitDao.insertHabits(sampleHabits)
        }
    }
}
