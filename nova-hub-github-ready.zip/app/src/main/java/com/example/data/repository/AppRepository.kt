package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.HabitItem
import com.example.data.model.NoteItem
import com.example.data.model.TaskItem
import kotlinx.coroutines.flow.Flow

class AppRepository(private val database: AppDatabase) {
    private val taskDao = database.taskDao()
    private val noteDao = database.noteDao()
    private val habitDao = database.habitDao()

    val allTasks: Flow<List<TaskItem>> = taskDao.getAllTasks()
    val allNotes: Flow<List<NoteItem>> = noteDao.getAllNotes()
    val allHabits: Flow<List<HabitItem>> = habitDao.getAllHabits()

    suspend fun insertTask(task: TaskItem): Long = taskDao.insertTask(task)
    suspend fun updateTask(task: TaskItem) = taskDao.updateTask(task)
    suspend fun deleteTask(task: TaskItem) = taskDao.deleteTask(task)
    suspend fun deleteTaskById(id: Long) = taskDao.deleteTaskById(id)
    suspend fun toggleTaskCompleted(id: Long, completed: Boolean) = taskDao.setTaskCompleted(id, completed)

    suspend fun insertNote(note: NoteItem): Long = noteDao.insertNote(note)
    suspend fun updateNote(note: NoteItem) = noteDao.updateNote(note)
    suspend fun deleteNote(note: NoteItem) = noteDao.deleteNote(note)
    suspend fun deleteNoteById(id: Long) = noteDao.deleteNoteById(id)

    suspend fun updateHabit(habit: HabitItem) = habitDao.updateHabit(habit)
    suspend fun toggleHabit(habit: HabitItem) {
        val updated = habit.copy(
            isCompletedToday = !habit.isCompletedToday,
            streak = if (!habit.isCompletedToday) habit.streak + 1 else maxOf(0, habit.streak - 1)
        )
        habitDao.updateHabit(updated)
    }

    suspend fun resetWithSampleData() {
        AppDatabase.populateDatabase(database)
    }
}
