package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority {
    LOW, MEDIUM, HIGH, URGENT
}

enum class TaskCategory(val label: String, val iconName: String, val colorHex: Long) {
    WORK("Work", "work", 0xFF6366F1),
    DEVELOPMENT("Dev", "code", 0xFF06B6D4),
    DESIGN("Design", "palette", 0xFFEC4899),
    PERSONAL("Personal", "person", 0xFF10B981),
    HEALTH("Health", "fitness_center", 0xFFF59E0B),
    FINANCE("Finance", "account_balance", 0xFF8B5CF6)
}

enum class TaskStatus {
    TODO, IN_PROGRESS, REVIEW, COMPLETED
}

@Entity(tableName = "tasks")
data class TaskItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = TaskCategory.WORK.name,
    val priority: String = Priority.MEDIUM.name,
    val status: String = TaskStatus.TODO.name,
    val dueDate: String = "",
    val isCompleted: Boolean = false,
    val subtasksRaw: String = "", // Comma or newline separated
    val estimatedMinutes: Int = 30,
    val createdAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
) {
    val subtasks: List<String>
        get() = if (subtasksRaw.isBlank()) emptyList() else subtasksRaw.split("||").filter { it.isNotBlank() }

    val categoryEnum: TaskCategory
        get() = try { TaskCategory.valueOf(category) } catch (e: Exception) { TaskCategory.WORK }

    val priorityEnum: Priority
        get() = try { Priority.valueOf(priority) } catch (e: Exception) { Priority.MEDIUM }

    val statusEnum: TaskStatus
        get() = try { TaskStatus.valueOf(status) } catch (e: Exception) { TaskStatus.TODO }
}

@Entity(tableName = "notes")
data class NoteItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val tag: String = "General",
    val colorHex: Long = 0xFF6366F1,
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_habits")
data class HabitItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val targetDays: Int = 7,
    val streak: Int = 0,
    val isCompletedToday: Boolean = false,
    val icon: String = "check_circle",
    val colorHex: Long = 0xFF10B981
)
