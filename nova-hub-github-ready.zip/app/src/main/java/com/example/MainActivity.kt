package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.FluidNavigationBar
import com.example.ui.components.FocusTimerModal
import com.example.ui.components.NoteEditorSheet
import com.example.ui.components.TaskDetailSheet
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.M3Primary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                NovaHubApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NovaHubApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val pendingTasksCount = allTasks.count { !it.isCompleted }

    val isTaskSheetOpen by viewModel.isTaskSheetOpen.collectAsState()
    val editingTask by viewModel.editingTask.collectAsState()

    val isNoteSheetOpen by viewModel.isNoteSheetOpen.collectAsState()
    val editingNote by viewModel.editingNote.collectAsState()

    val isFocusTimerOpen by viewModel.isFocusTimerOpen.collectAsState()
    val focusTimerState by viewModel.focusTimerState.collectAsState()

    val notification by viewModel.notification.collectAsState()

    // Auto-dismiss notification after 3.5 seconds
    LaunchedEffect(notification) {
        if (notification != null) {
            delay(3500)
            viewModel.dismissNotification()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_scaffold"),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.statusBars,
        bottomBar = {
            FluidNavigationBar(
                currentScreen = currentScreen,
                onScreenSelected = { screen -> viewModel.navigateTo(screen) },
                pendingTasksCount = pendingTasksCount
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            // Smooth Screen Transitions
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    val isForward = targetState.ordinal > initialState.ordinal
                    if (isForward) {
                        (slideInHorizontally(
                            initialOffsetX = { it / 3 },
                            animationSpec = tween(300)
                        ) + fadeIn(animationSpec = tween(300))).togetherWith(
                            slideOutHorizontally(
                                targetOffsetX = { -it / 3 },
                                animationSpec = tween(300)
                            ) + fadeOut(animationSpec = tween(200))
                        )
                    } else {
                        (slideInHorizontally(
                            initialOffsetX = { -it / 3 },
                            animationSpec = tween(300)
                        ) + fadeIn(animationSpec = tween(300))).togetherWith(
                            slideOutHorizontally(
                                targetOffsetX = { it / 3 },
                                animationSpec = tween(300)
                            ) + fadeOut(animationSpec = tween(200))
                        )
                    }
                },
                label = "screen_transition"
            ) { targetScreen ->
                when (targetScreen) {
                    AppScreen.HOME -> HomeScreen(viewModel = viewModel, innerPadding = innerPadding)
                    AppScreen.TASKS -> TasksScreen(viewModel = viewModel, innerPadding = innerPadding)
                    AppScreen.ANALYTICS -> AnalyticsScreen(viewModel = viewModel, innerPadding = innerPadding)
                    AppScreen.NOTES -> NotesScreen(viewModel = viewModel, innerPadding = innerPadding)
                    AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel, innerPadding = innerPadding)
                }
            }

            // Top Floating Notification Toast
            AnimatedVisibility(
                visible = notification != null,
                enter = fadeIn() + androidx.compose.animation.slideInVertically { -it },
                exit = fadeOut() + androidx.compose.animation.slideOutVertically { -it },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(top = 16.dp, start = 20.dp, end = 20.dp)
            ) {
                notification?.let { notif ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, M3Primary.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                        tonalElevation = 8.dp
                    ) {
                        Box(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = notif.message,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Task Bottom Sheet
    if (isTaskSheetOpen) {
        TaskDetailSheet(
            task = editingTask,
            onDismiss = { viewModel.closeTaskSheet() },
            onSave = { title, desc, cat, priority, date, subtasks, mins, pinned ->
                viewModel.saveTask(title, desc, cat, priority, date, subtasks, mins, pinned)
            }
        )
    }

    // Modal Note Bottom Sheet
    if (isNoteSheetOpen) {
        NoteEditorSheet(
            note = editingNote,
            onDismiss = { viewModel.closeNoteSheet() },
            onSave = { title, content, tag, colorHex, pinned ->
                viewModel.saveNote(title, content, tag, colorHex, pinned)
            }
        )
    }

    // Focus Timer Modal Dialog
    if (isFocusTimerOpen) {
        FocusTimerModal(
            state = focusTimerState,
            onToggle = { viewModel.toggleFocusTimer() },
            onReset = { minutes -> viewModel.resetFocusTimer(minutes) },
            onDismiss = { viewModel.closeFocusTimer() }
        )
    }
}
