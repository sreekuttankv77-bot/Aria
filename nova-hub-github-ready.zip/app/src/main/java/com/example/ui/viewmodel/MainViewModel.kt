package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.HabitItem
import com.example.data.model.NoteItem
import com.example.data.model.Priority
import com.example.data.model.TaskCategory
import com.example.data.model.TaskItem
import com.example.data.model.TaskStatus
import com.example.data.repository.AppRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen(val title: String, val icon: String) {
    HOME("Dashboard", "dashboard"),
    TASKS("Tasks", "checklist"),
    ANALYTICS("Pulse", "insights"),
    NOTES("Ideas", "lightbulb"),
    SETTINGS("Settings", "settings")
}

data class FocusTimerState(
    val isRunning: Boolean = false,
    val totalSeconds: Int = 25 * 60,
    val remainingSeconds: Int = 25 * 60,
    val completedSessionsToday: Int = 3,
    val currentTaskTitle: String = "Sprint Development Block"
)

data class UiNotification(
    val message: String,
    val id: Long = System.currentTimeMillis()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = AppRepository(database)

    // Navigation State
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Filter & Search State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<TaskCategory?>(null)
    val selectedCategory: StateFlow<TaskCategory?> = _selectedCategory.asStateFlow()

    private val _selectedStatus = MutableStateFlow<TaskStatus?>(null)
    val selectedStatus: StateFlow<TaskStatus?> = _selectedStatus.asStateFlow()

    // Sheet / Dialog states
    private val _isTaskSheetOpen = MutableStateFlow(false)
    val isTaskSheetOpen: StateFlow<Boolean> = _isTaskSheetOpen.asStateFlow()

    private val _editingTask = MutableStateFlow<TaskItem?>(null)
    val editingTask: StateFlow<TaskItem?> = _editingTask.asStateFlow()

    private val _isNoteSheetOpen = MutableStateFlow(false)
    val isNoteSheetOpen: StateFlow<Boolean> = _isNoteSheetOpen.asStateFlow()

    private val _editingNote = MutableStateFlow<NoteItem?>(null)
    val editingNote: StateFlow<NoteItem?> = _editingNote.asStateFlow()

    private val _isFocusTimerOpen = MutableStateFlow(false)
    val isFocusTimerOpen: StateFlow<Boolean> = _isFocusTimerOpen.asStateFlow()

    // Focus Timer State
    private val _focusTimerState = MutableStateFlow(FocusTimerState())
    val focusTimerState: StateFlow<FocusTimerState> = _focusTimerState.asStateFlow()
    private var timerJob: Job? = null

    // SnackBar / Alert Notification
    private val _notification = MutableStateFlow<UiNotification?>(null)
    val notification: StateFlow<UiNotification?> = _notification.asStateFlow()

    // Theme Mode (Dark = true, Light = false, System default follows dark)
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Raw flows
    val allTasks: StateFlow<List<TaskItem>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotes: StateFlow<List<NoteItem>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHabits: StateFlow<List<HabitItem>> = repository.allHabits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Tasks Flow
    val filteredTasks: StateFlow<List<TaskItem>> = combine(
        allTasks,
        _searchQuery,
        _selectedCategory,
        _selectedStatus
    ) { tasks, query, category, status ->
        tasks.filter { task ->
            val matchesQuery = query.isBlank() ||
                task.title.contains(query, ignoreCase = true) ||
                task.description.contains(query, ignoreCase = true) ||
                task.category.contains(query, ignoreCase = true)

            val matchesCategory = category == null || task.categoryEnum == category
            val matchesStatus = status == null || task.statusEnum == status

            matchesQuery && matchesCategory && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Notes Flow
    val filteredNotes: StateFlow<List<NoteItem>> = combine(
        allNotes,
        _searchQuery
    ) { notes, query ->
        if (query.isBlank()) {
            notes
        } else {
            notes.filter { note ->
                note.title.contains(query, ignoreCase = true) ||
                note.content.contains(query, ignoreCase = true) ||
                note.tag.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Navigation Actions
    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: TaskCategory?) {
        _selectedCategory.value = if (_selectedCategory.value == category) null else category
    }

    fun selectStatus(status: TaskStatus?) {
        _selectedStatus.value = if (_selectedStatus.value == status) null else status
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    // Task Actions
    fun openCreateTaskSheet() {
        _editingTask.value = null
        _isTaskSheetOpen.value = true
    }

    fun openEditTaskSheet(task: TaskItem) {
        _editingTask.value = task
        _isTaskSheetOpen.value = true
    }

    fun closeTaskSheet() {
        _isTaskSheetOpen.value = false
        _editingTask.value = null
    }

    fun saveTask(
        title: String,
        description: String,
        category: TaskCategory,
        priority: Priority,
        dueDate: String,
        subtasks: List<String>,
        estimatedMinutes: Int,
        isPinned: Boolean
    ) {
        viewModelScope.launch {
            val current = _editingTask.value
            val subtasksRaw = subtasks.filter { it.isNotBlank() }.joinToString("||")
            if (current == null) {
                val newTask = TaskItem(
                    title = title,
                    description = description,
                    category = category.name,
                    priority = priority.name,
                    status = TaskStatus.TODO.name,
                    dueDate = dueDate,
                    subtasksRaw = subtasksRaw,
                    estimatedMinutes = estimatedMinutes,
                    isPinned = isPinned
                )
                repository.insertTask(newTask)
                showNotification("Task created: $title")
            } else {
                val updatedTask = current.copy(
                    title = title,
                    description = description,
                    category = category.name,
                    priority = priority.name,
                    dueDate = dueDate,
                    subtasksRaw = subtasksRaw,
                    estimatedMinutes = estimatedMinutes,
                    isPinned = isPinned
                )
                repository.updateTask(updatedTask)
                showNotification("Task updated: $title")
            }
            closeTaskSheet()
        }
    }

    fun toggleTaskCompleted(task: TaskItem) {
        viewModelScope.launch {
            val newCompleted = !task.isCompleted
            repository.toggleTaskCompleted(task.id, newCompleted)
            showNotification(if (newCompleted) "Completed: ${task.title}" else "Reopened: ${task.title}")
        }
    }

    fun updateTaskStatus(task: TaskItem, newStatus: TaskStatus) {
        viewModelScope.launch {
            val updated = task.copy(
                status = newStatus.name,
                isCompleted = (newStatus == TaskStatus.COMPLETED)
            )
            repository.updateTask(updated)
        }
    }

    fun deleteTask(task: TaskItem) {
        viewModelScope.launch {
            repository.deleteTask(task)
            showNotification("Deleted task: ${task.title}")
        }
    }

    fun toggleTaskPin(task: TaskItem) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isPinned = !task.isPinned))
        }
    }

    // Note Actions
    fun openCreateNoteSheet() {
        _editingNote.value = null
        _isNoteSheetOpen.value = true
    }

    fun openEditNoteSheet(note: NoteItem) {
        _editingNote.value = note
        _isNoteSheetOpen.value = true
    }

    fun closeNoteSheet() {
        _isNoteSheetOpen.value = false
        _editingNote.value = null
    }

    fun saveNote(
        title: String,
        content: String,
        tag: String,
        colorHex: Long,
        isPinned: Boolean
    ) {
        viewModelScope.launch {
            val current = _editingNote.value
            if (current == null) {
                val newNote = NoteItem(
                    title = title,
                    content = content,
                    tag = tag,
                    colorHex = colorHex,
                    isPinned = isPinned,
                    updatedAt = System.currentTimeMillis()
                )
                repository.insertNote(newNote)
                showNotification("Note added: $title")
            } else {
                val updatedNote = current.copy(
                    title = title,
                    content = content,
                    tag = tag,
                    colorHex = colorHex,
                    isPinned = isPinned,
                    updatedAt = System.currentTimeMillis()
                )
                repository.updateNote(updatedNote)
                showNotification("Note updated: $title")
            }
            closeNoteSheet()
        }
    }

    fun deleteNote(note: NoteItem) {
        viewModelScope.launch {
            repository.deleteNote(note)
            showNotification("Deleted note: ${note.title}")
        }
    }

    fun toggleNotePin(note: NoteItem) {
        viewModelScope.launch {
            repository.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    // Habit Actions
    fun toggleHabit(habit: HabitItem) {
        viewModelScope.launch {
            repository.toggleHabit(habit)
        }
    }

    // Focus Timer Controls
    fun openFocusTimer(taskTitle: String? = null) {
        if (taskTitle != null) {
            _focusTimerState.value = _focusTimerState.value.copy(currentTaskTitle = taskTitle)
        }
        _isFocusTimerOpen.value = true
    }

    fun closeFocusTimer() {
        _isFocusTimerOpen.value = false
    }

    fun toggleFocusTimer() {
        val current = _focusTimerState.value
        if (current.isRunning) {
            pauseFocusTimer()
        } else {
            startFocusTimer()
        }
    }

    private fun startFocusTimer() {
        _focusTimerState.value = _focusTimerState.value.copy(isRunning = true)
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_focusTimerState.value.remainingSeconds > 0 && _focusTimerState.value.isRunning) {
                delay(1000)
                val newRemaining = _focusTimerState.value.remainingSeconds - 1
                if (newRemaining <= 0) {
                    _focusTimerState.value = _focusTimerState.value.copy(
                        isRunning = false,
                        remainingSeconds = _focusTimerState.value.totalSeconds,
                        completedSessionsToday = _focusTimerState.value.completedSessionsToday + 1
                    )
                    showNotification("Focus Session Finished! Great job!")
                    break
                } else {
                    _focusTimerState.value = _focusTimerState.value.copy(remainingSeconds = newRemaining)
                }
            }
        }
    }

    private fun pauseFocusTimer() {
        _focusTimerState.value = _focusTimerState.value.copy(isRunning = false)
        timerJob?.cancel()
    }

    fun resetFocusTimer(minutes: Int = 25) {
        pauseFocusTimer()
        val seconds = minutes * 60
        _focusTimerState.value = _focusTimerState.value.copy(
            totalSeconds = seconds,
            remainingSeconds = seconds
        )
    }

    // Reset Database
    fun resetWithSampleData() {
        viewModelScope.launch {
            repository.resetWithSampleData()
            showNotification("Reset data with default samples")
        }
    }

    fun showNotification(msg: String) {
        _notification.value = UiNotification(msg)
    }

    fun dismissNotification() {
        _notification.value = null
    }
}
