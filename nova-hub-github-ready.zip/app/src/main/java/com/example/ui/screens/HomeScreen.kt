package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HabitItem
import com.example.data.model.Priority
import com.example.ui.components.HeaderGreeting
import com.example.ui.components.PulseActivityChart
import com.example.ui.components.SearchBarInput
import com.example.ui.components.StatMetricCard
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.AccentSuccess
import com.example.ui.theme.AccentWarning
import com.example.ui.theme.M3AccentPurple
import com.example.ui.theme.M3DarkPurple
import com.example.ui.theme.M3OnPrimaryContainer
import com.example.ui.theme.M3Primary
import com.example.ui.theme.M3PrimaryContainer
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    innerPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.allTasks.collectAsState()
    val habits by viewModel.allHabits.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val completedTasks = tasks.count { it.isCompleted }
    val totalTasks = tasks.size
    val completionRate = if (totalTasks > 0) completedTasks.toFloat() / totalTasks.toFloat() else 0f

    val urgentOrPinnedTasks = tasks.filter { !it.isCompleted && (it.isPinned || it.priorityEnum == Priority.URGENT || it.priorityEnum == Priority.HIGH) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header Greeting with Bold Headline
        item {
            HeaderGreeting(
                userName = "Alex",
                streakCount = 14,
                headlineText = "PROJECTS",
                onOpenTimer = { viewModel.openFocusTimer() }
            )
        }

        // Search Pill
        item {
            SearchBarInput(
                query = searchQuery,
                onQueryChange = { viewModel.setSearchQuery(it) },
                placeholder = "Search repositories, tasks..."
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Quick Stats Metric Cards
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatMetricCard(
                    title = "Tasks Done",
                    value = "$completedTasks/$totalTasks",
                    subtitle = "${(completionRate * 100).toInt()}% Velocity",
                    icon = Icons.Filled.TaskAlt,
                    accentColor = M3Primary,
                    progress = completionRate,
                    onClick = { viewModel.navigateTo(AppScreen.TASKS) },
                    modifier = Modifier.weight(1f)
                )

                StatMetricCard(
                    title = "Deep Focus",
                    value = "3.5h",
                    subtitle = "+24% vs yday",
                    icon = Icons.Filled.Timer,
                    accentColor = M3Primary,
                    progress = 0.75f,
                    onClick = { viewModel.openFocusTimer() },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Productivity Pulse Chart Card
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                PulseActivityChart()
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Daily Habits Tracker
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE HABITS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${habits.count { it.isCompletedToday }}/${habits.size} COMPLETED",
                        fontSize = 10.sp,
                        color = M3Primary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(habits) { habit ->
                        HabitQuickPill(
                            habit = habit,
                            onToggle = { viewModel.toggleHabit(habit) }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Priority Section Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HIGH PRIORITY",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    letterSpacing = 1.sp
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.navigateTo(AppScreen.TASKS) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "VIEW ALL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = M3Primary,
                        letterSpacing = 0.8.sp
                    )
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = "View all tasks",
                        tint = M3Primary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Priority Tasks
        if (urgentOrPinnedTasks.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Box(
                        modifier = Modifier.padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🎉 All high priority tasks cleared!",
                            fontSize = 14.sp,
                            color = AccentSuccess,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            items(urgentOrPinnedTasks) { task ->
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp)) {
                    TaskItemCard(
                        task = task,
                        onToggleCompleted = { viewModel.toggleTaskCompleted(task) },
                        onEdit = { viewModel.openEditTaskSheet(task) },
                        onDelete = { viewModel.deleteTask(task) },
                        onPinToggle = { viewModel.toggleTaskPin(task) },
                        onStartFocus = { viewModel.openFocusTimer(task.title) }
                    )
                }
            }
        }

        // Action Buttons Row
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.openCreateTaskSheet() },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("home_add_task_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = M3Primary,
                        contentColor = Color.White
                    )
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Task", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "NEW TASK", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                }

                Button(
                    onClick = { viewModel.openCreateNoteSheet() },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("home_add_note_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = M3PrimaryContainer,
                        contentColor = M3OnPrimaryContainer
                    )
                ) {
                    Icon(imageVector = Icons.Filled.Lightbulb, contentDescription = "Add Idea", tint = M3Primary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "QUICK IDEA", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                }
            }
        }
    }
}

@Composable
fun HabitQuickPill(
    habit: HabitItem,
    onToggle: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { onToggle() }
            .border(
                1.dp,
                if (habit.isCompletedToday) M3Primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        color = if (habit.isCompletedToday) M3PrimaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (habit.isCompletedToday) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircleOutline,
                contentDescription = "Toggle Habit",
                tint = if (habit.isCompletedToday) M3Primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Text(
                    text = habit.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.LocalFireDepartment,
                        contentDescription = "Streak",
                        tint = AccentWarning,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${habit.streak}d streak",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
