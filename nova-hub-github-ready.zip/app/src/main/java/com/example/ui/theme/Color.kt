package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bold Typography Palette - Material 3 Deep Violet & Lavender System
val M3Primary = Color(0xFF6750A4)
val M3OnPrimary = Color(0xFFFFFFFF)
val M3PrimaryContainer = Color(0xFFEADDFF)
val M3OnPrimaryContainer = Color(0xFF21005D)

val M3Secondary = Color(0xFF625B71)
val M3OnSecondary = Color(0xFFFFFFFF)
val M3SecondaryContainer = Color(0xFFE8DEF8)
val M3OnSecondaryContainer = Color(0xFF1D192B)

val M3Tertiary = Color(0xFF7D5260)
val M3TertiaryContainer = Color(0xFFFFD8E4)
val M3OnTertiaryContainer = Color(0xFF31111D)

val M3AccentPurple = Color(0xFFD0BCFF)
val M3DarkPurple = Color(0xFF381E72)

// Light Theme Canvas & Surfaces
val BoldLightBg = Color(0xFFFEF7FF)
val BoldLightSurface = Color(0xFFF7F2FA)
val BoldLightSurfaceElevated = Color(0xFFFFFFFF)
val BoldLightSurfaceVariant = Color(0xFFF3EDF7)
val BoldLightBorder = Color(0xFFE6E0E9)
val BoldLightOutline = Color(0xFFCAC4D0)
val BoldLightTextPrimary = Color(0xFF1D1B20)
val BoldLightTextSecondary = Color(0xFF49454F)
val BoldLightTextMuted = Color(0xFF79747E)

// Dark Theme Canvas & Surfaces
val BoldDarkBg = Color(0xFF141218)
val BoldDarkSurface = Color(0xFF1D1B20)
val BoldDarkSurfaceElevated = Color(0xFF2B2930)
val BoldDarkSurfaceVariant = Color(0xFF211F26)
val BoldDarkBorder = Color(0xFF49454F)
val BoldDarkOutline = Color(0xFF938F99)
val BoldDarkTextPrimary = Color(0xFFE6E0E9)
val BoldDarkTextSecondary = Color(0xFFCAC4D0)
val BoldDarkTextMuted = Color(0xFF938F99)

// Accent Category Badges
val AccentKotlin = Color(0xFF6750A4)
val AccentPublic = Color(0xFF21005D)
val AccentPublicBg = Color(0xFFEADDFF)
val AccentSuccess = Color(0xFF2E7D32)
val AccentWarning = Color(0xFFE65100)
val AccentError = Color(0xFFB3261E)

enum class AppThemePreset(val label: String, val primary: Color, val secondary: Color) {
    PURPLE("Bold Violet", Color(0xFF6750A4), Color(0xFFD0BCFF)),
    INDIGO("Deep Indigo", Color(0xFF3F51B5), Color(0xFFC5CAE9)),
    SLATE("Monochrome Slate", Color(0xFF37474F), Color(0xFFCFD8DC)),
    BERRY("Bold Berry", Color(0xFF880E4F), Color(0xFFF8BBD0))
}
