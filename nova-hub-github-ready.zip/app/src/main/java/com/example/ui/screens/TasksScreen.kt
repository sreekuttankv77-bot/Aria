package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TaskCategory
import com.example.data.model.TaskStatus
import com.example.ui.components.SearchBarInput
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.AccentPublic
import com.example.ui.theme.AccentPublicBg
import com.example.ui.theme.M3AccentPurple
import com.example.ui.theme.M3DarkPurple
import com.example.ui.theme.M3OnPrimaryContainer
import com.example.ui.theme.M3Primary
import com.example.ui.theme.M3PrimaryContainer
import com.example.ui.viewmodel.MainViewModel

@Composable
fun TasksScreen(
    viewModel: MainViewModel,
    innerPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.filteredTasks.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedStatus by viewModel.selectedStatus.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(innerPadding)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Big Bold Header
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Text(
                        text = "TASK REPOSITORY",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${allTasks.count { !it.isCompleted }} PENDING • ${allTasks.count { it.isCompleted }} COMPLETED",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        letterSpacing = 1.sp
                    )
                }
            }

            // Search Bar Pill
            item {
                SearchBarInput(
                    query = searchQuery,
                    onQueryChange = { viewModel.setSearchQuery(it) },
                    placeholder = "Filter tasks by title or category..."
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Status Tabs
            item {
                StatusTabsRow(
                    selectedStatus = selectedStatus,
                    onStatusSelected = { viewModel.selectStatus(it) }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Category Chips Row
            item {
                CategoryChipsRow(
                    selectedCategory = selectedCategory,
                    onCategorySelected = { viewModel.selectCategory(it) }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Tasks List
            if (tasks.isEmpty()) {
                item {
                    EmptyTasksState(
                        isFiltered = searchQuery.isNotEmpty() || selectedCategory != null || selectedStatus != null,
                        onCreateNew = { viewModel.openCreateTaskSheet() }
                    )
                }
            } else {
                items(tasks, key = { it.id }) { task ->
                    Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp)) {
                        TaskItemCard(
                            task = task,
                            onToggleCompleted = { viewModel.toggleTaskCompleted(task) },
                            onEdit = { viewModel.openEditTaskSheet(task) },
                            onDelete = { viewModel.deleteTask(task) },
                            onPinToggle = { viewModel.toggleTaskPin(task) },
                            onStartFocus = { viewModel.openFocusTimer(task.title) }
                        )
                    }
                }
            }
        }

        // Lavender Styled FAB matching HTML: <button class='w-16 h-16 bg-[#D0BCFF] text-[#381E72] rounded-2xl shadow-xl'>
        FloatingActionButton(
            onClick = { viewModel.openCreateTaskSheet() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 24.dp, bottom = 85.dp)
                .size(64.dp)
                .testTag("add_task_fab"),
            containerColor = M3AccentPurple,
            contentColor = M3DarkPurple,
            shape = RoundedCornerShape(20.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add Task",
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
fun StatusTabsRow(
    selectedStatus: TaskStatus?,
    onStatusSelected: (TaskStatus?) -> Unit
) {
    val tabs = listOf<Pair<String, TaskStatus?>>(
        "ALL" to null,
        "TO DO" to TaskStatus.TODO,
        "IN PROGRESS" to TaskStatus.IN_PROGRESS,
        "COMPLETED" to TaskStatus.COMPLETED
    )

    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(tabs) { (label, status) ->
            val isSelected = selectedStatus == status
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onStatusSelected(status) }
                    .border(
                        width = 1.dp,
                        color = if (isSelected) M3Primary else MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(16.dp)
                    ),
                shape = RoundedCornerShape(16.dp),
                color = if (isSelected) M3PrimaryContainer else MaterialTheme.colorScheme.surface
            ) {
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) M3OnPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
fun CategoryChipsRow(
    selectedCategory: TaskCategory?,
    onCategorySelected: (TaskCategory?) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(TaskCategory.values()) { cat ->
            val isSelected = selectedCategory == cat
            val catColor = Color(cat.colorHex)

            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onCategorySelected(cat) }
                    .border(
                        width = 1.dp,
                        color = if (isSelected) M3Primary else MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(12.dp)
                    ),
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) M3PrimaryContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) M3Primary else catColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = cat.label.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) M3OnPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyTasksState(
    isFiltered: Boolean,
    onCreateNew: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 32.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(M3PrimaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Checklist,
                    contentDescription = "No Tasks",
                    tint = M3Primary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isFiltered) "NO MATCHING TASKS" else "REPOSITORY EMPTY",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isFiltered) "Try adjusting your search query or filters" else "Add your first goal or repository task.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (!isFiltered) {
                Spacer(modifier = Modifier.height(16.dp))
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onCreateNew() },
                    color = M3Primary,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "+ CREATE TASK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}
