package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = M3AccentPurple,
    onPrimary = M3DarkPurple,
    primaryContainer = M3Primary,
    onPrimaryContainer = M3PrimaryContainer,
    secondary = M3SecondaryContainer,
    onSecondary = M3OnSecondaryContainer,
    secondaryContainer = Color(0xFF4A4458),
    onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = M3TertiaryContainer,
    onTertiary = M3OnTertiaryContainer,
    background = BoldDarkBg,
    onBackground = BoldDarkTextPrimary,
    surface = BoldDarkSurface,
    onSurface = BoldDarkTextPrimary,
    surfaceVariant = BoldDarkSurfaceElevated,
    onSurfaceVariant = BoldDarkTextSecondary,
    outline = BoldDarkBorder,
    outlineVariant = BoldDarkOutline,
    error = AccentError
)

private val LightColorScheme = lightColorScheme(
    primary = M3Primary,
    onPrimary = M3OnPrimary,
    primaryContainer = M3PrimaryContainer,
    onPrimaryContainer = M3OnPrimaryContainer,
    secondary = M3Secondary,
    onSecondary = M3OnSecondary,
    secondaryContainer = M3SecondaryContainer,
    onSecondaryContainer = M3OnSecondaryContainer,
    tertiary = M3Tertiary,
    onTertiary = Color.White,
    tertiaryContainer = M3TertiaryContainer,
    onTertiaryContainer = M3OnTertiaryContainer,
    background = BoldLightBg,
    onBackground = BoldLightTextPrimary,
    surface = BoldLightSurface,
    onSurface = BoldLightTextPrimary,
    surfaceVariant = BoldLightSurfaceVariant,
    onSurfaceVariant = BoldLightTextSecondary,
    outline = BoldLightBorder,
    outlineVariant = BoldLightOutline,
    error = AccentError
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
