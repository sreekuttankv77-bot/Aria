package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FrostedGlassColorScheme = darkColorScheme(
    primary = FrostedLilac,
    onPrimary = FrostedDeepPurple,
    primaryContainer = FrostedPurple,
    onPrimaryContainer = FrostedLilacLight,
    secondary = FrostedLilac,
    onSecondary = FrostedDeepPurple,
    secondaryContainer = FrostedDarkSurface,
    onSecondaryContainer = FrostedLilacLight,
    tertiary = FrostedPlum,
    onTertiary = Color.White,
    background = FrostedDarkBg,
    onBackground = FrostedTextPrimary,
    surface = FrostedDarkSurface,
    onSurface = FrostedTextPrimary,
    surfaceVariant = FrostedDarkSurface,
    onSurfaceVariant = FrostedTextSecondary,
    outline = FrostedCardGlassBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Keep consistent frosted glass styling
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FrostedGlassColorScheme,
        typography = Typography,
        content = content
    )
}
