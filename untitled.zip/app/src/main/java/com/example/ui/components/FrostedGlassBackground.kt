package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.FrostedDarkBg
import com.example.ui.theme.FrostedLilac
import com.example.ui.theme.FrostedPlum
import com.example.ui.theme.FrostedPurple

@Composable
fun FrostedGlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_glow")
    
    val pulse1 by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween( durationMillis = 4800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse1"
    )

    val pulse2 by infiniteTransition.animateFloat(
        initialValue = 1.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse2"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FrostedDarkBg)
    ) {
        // Glowing Ambient Radial Orbs Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Top-Left Royal Violet Orb (#4F378B)
            val orb1Center = Offset(width * 0.05f, height * 0.05f)
            val orb1Radius = (width * 0.75f) * pulse1
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        FrostedPurple.copy(alpha = 0.55f),
                        FrostedPurple.copy(alpha = 0.28f),
                        Color.Transparent
                    ),
                    center = orb1Center,
                    radius = orb1Radius
                ),
                center = orb1Center,
                radius = orb1Radius
            )

            // Center-Right Lavender Bloom Orb (#D0BCFF)
            val orb2Center = Offset(width * 0.95f, height * 0.45f)
            val orb2Radius = (width * 0.65f) * pulse2
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        FrostedLilac.copy(alpha = 0.32f),
                        FrostedLilac.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = orb2Center,
                    radius = orb2Radius
                ),
                center = orb2Center,
                radius = orb2Radius
            )

            // Bottom-Left / Center Deep Plum Orb (#31111D)
            val orb3Center = Offset(width * 0.3f, height * 0.92f)
            val orb3Radius = (width * 0.7f) * pulse1
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        FrostedPlum.copy(alpha = 0.65f),
                        FrostedPlum.copy(alpha = 0.3f),
                        Color.Transparent
                    ),
                    center = orb3Center,
                    radius = orb3Radius
                ),
                center = orb3Center,
                radius = orb3Radius
            )
        }

        // Overlay Content
        content()
    }
}
