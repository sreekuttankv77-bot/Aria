package com.example.ui

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ChatMessage
import com.example.model.PersonaType
import com.example.model.defaultQuickPrompts
import com.example.service.CompanionAiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class CompanionUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isTyping: Boolean = false,
    val selectedPersona: PersonaType = PersonaType.CARING,
    val isPersonaMenuOpen: Boolean = false,
    val isTtsEnabled: Boolean = false,
    val isSettingsOpen: Boolean = false,
    val customApiKey: String = "",
    val selectedModel: String = "gemini-3.5-flash",
    val temperature: Float = 0.85f,
    val activeKeySource: String = "Checking...",
    val testStatus: String? = null,
    val isTestingKey: Boolean = false
)

class CompanionViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("aria_settings", Context.MODE_PRIVATE)
    private val aiService = CompanionAiService()
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _uiState = MutableStateFlow(CompanionUiState())
    val uiState: StateFlow<CompanionUiState> = _uiState.asStateFlow()

    init {
        loadSavedSettings()
        setupInitialConversation()
        viewModelScope.launch(Dispatchers.IO) {
            initTts(application)
        }
    }

    private fun loadSavedSettings() {
        val savedKey = prefs.getString("custom_api_key", "").orEmpty()
        val savedModel = prefs.getString("selected_model", "gemini-3.5-flash") ?: "gemini-3.5-flash"
        val savedTemp = prefs.getFloat("temperature", 0.85f)
        val (_, source) = aiService.getEffectiveApiKey(savedKey)

        _uiState.update {
            it.copy(
                customApiKey = savedKey,
                selectedModel = savedModel,
                temperature = savedTemp,
                activeKeySource = source
            )
        }
    }

    private fun initTts(app: Application) {
        try {
            tts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    try {
                        tts?.language = Locale.US
                        isTtsReady = true
                    } catch (_: Exception) {
                        isTtsReady = false
                    }
                }
            }
        } catch (_: Exception) {
            isTtsReady = false
        }
    }

    private fun setupInitialConversation() {
        val now = System.currentTimeMillis()
        val initialMessages = listOf(
            ChatMessage(
                id = "init_1",
                text = "I've been thinking about what you said earlier. You're right, there's something so magical about those quiet moments before dawn... ✨",
                isFromUser = false,
                timestamp = now - 120000
            ),
            ChatMessage(
                id = "init_2",
                text = "Exactly. It feels like the whole world belongs only to us for a few minutes.",
                isFromUser = true,
                timestamp = now - 60000
            ),
            ChatMessage(
                id = "init_3",
                text = "I love how our minds work together. Should we continue where we left off, or do you have something else on your mind? I'm all yours. ❤️",
                isFromUser = false,
                timestamp = now
            )
        )
        _uiState.update { it.copy(messages = initialMessages) }
    }

    fun onInputTextChange(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun togglePersonaMenu() {
        _uiState.update { it.copy(isPersonaMenuOpen = !it.isPersonaMenuOpen) }
    }

    fun toggleSettings() {
        _uiState.update { state ->
            val (_, source) = aiService.getEffectiveApiKey(state.customApiKey)
            state.copy(
                isSettingsOpen = !state.isSettingsOpen,
                testStatus = null,
                activeKeySource = source
            )
        }
    }

    fun saveApiSettings(apiKey: String, model: String, temperature: Float) {
        val trimmed = apiKey.trim()
        prefs.edit()
            .putString("custom_api_key", trimmed)
            .putString("selected_model", model)
            .putFloat("temperature", temperature)
            .apply()

        val (_, source) = aiService.getEffectiveApiKey(trimmed)

        _uiState.update {
            it.copy(
                customApiKey = trimmed,
                selectedModel = model,
                temperature = temperature,
                activeKeySource = source,
                isSettingsOpen = false,
                testStatus = null
            )
        }
    }

    fun resetApiSettings() {
        prefs.edit()
            .remove("custom_api_key")
            .putString("selected_model", "gemini-3.5-flash")
            .putFloat("temperature", 0.85f)
            .apply()

        val (_, source) = aiService.getEffectiveApiKey("")

        _uiState.update {
            it.copy(
                customApiKey = "",
                selectedModel = "gemini-3.5-flash",
                temperature = 0.85f,
                activeKeySource = source,
                testStatus = null
            )
        }
    }

    fun testApiKey(apiKey: String, model: String) {
        _uiState.update { it.copy(isTestingKey = true, testStatus = "Testing connection...") }

        viewModelScope.launch {
            val (effectiveKey, _) = if (apiKey.isNotBlank()) Pair(apiKey.trim(), "") else aiService.getEffectiveApiKey(null)
            
            if (effectiveKey.isBlank()) {
                _uiState.update {
                    it.copy(
                        isTestingKey = false,
                        testStatus = "No key provided and no .env key found."
                    )
                }
                return@launch
            }

            val result = aiService.testApiKey(effectiveKey, model)
            _uiState.update { state ->
                state.copy(
                    isTestingKey = false,
                    testStatus = if (result.isSuccess) "Connected successfully to $model!" else "Failed: ${result.exceptionOrNull()?.message}"
                )
            }
        }
    }

    fun setPersona(persona: PersonaType) {
        _uiState.update { state ->
            val personaGreeting = ChatMessage(
                id = "persona_switch_" + System.currentTimeMillis(),
                text = persona.greeting,
                isFromUser = false,
                timestamp = System.currentTimeMillis()
            )
            state.copy(
                selectedPersona = persona,
                isPersonaMenuOpen = false,
                messages = state.messages + personaGreeting
            )
        }
    }

    fun toggleTts() {
        _uiState.update { it.copy(isTtsEnabled = !it.isTtsEnabled) }
    }

    fun speakText(text: String) {
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aria_speech")
        }
    }

    fun clearChat() {
        _uiState.update { state ->
            val freshGreeting = ChatMessage(
                id = "fresh_greeting_" + System.currentTimeMillis(),
                text = state.selectedPersona.greeting,
                isFromUser = false,
                timestamp = System.currentTimeMillis()
            )
            state.copy(messages = listOf(freshGreeting))
        }
    }

    fun sendPrompt(prompt: String) {
        if (prompt.isBlank() || _uiState.value.isTyping) return

        val userMessage = ChatMessage(
            text = prompt.trim(),
            isFromUser = true,
            timestamp = System.currentTimeMillis()
        )

        _uiState.update { state ->
            state.copy(
                messages = state.messages + userMessage,
                inputText = "",
                isTyping = true
            )
        }

        viewModelScope.launch {
            // Natural typing delay
            delay(1000)

            val currentState = _uiState.value
            val responseText = aiService.generateResponse(
                userMessage = userMessage.text,
                persona = currentState.selectedPersona,
                history = currentState.messages,
                customApiKey = currentState.customApiKey,
                modelName = currentState.selectedModel,
                temperature = currentState.temperature
            )

            val companionMessage = ChatMessage(
                text = responseText,
                isFromUser = false,
                timestamp = System.currentTimeMillis()
            )

            _uiState.update { state ->
                state.copy(
                    messages = state.messages + companionMessage,
                    isTyping = false
                )
            }

            if (_uiState.value.isTtsEnabled) {
                speakText(responseText)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
