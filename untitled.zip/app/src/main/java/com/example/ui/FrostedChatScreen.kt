package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PersonaType
import com.example.model.defaultQuickPrompts
import com.example.ui.components.ActiveIndicator
import com.example.ui.components.AriaAvatar
import com.example.ui.components.AriaMessageBubble
import com.example.ui.components.FrostedGlassBackground
import com.example.ui.components.FrostedGlassSurface
import com.example.ui.components.FrostedSuggestionChip
import com.example.ui.components.TypingDotsIndicator
import com.example.ui.components.UserMessageBubble
import com.example.ui.theme.FrostedActiveGreen
import com.example.ui.theme.FrostedDeepPurple
import com.example.ui.theme.FrostedLilac
import com.example.ui.theme.FrostedLilacLight
import com.example.ui.theme.FrostedPlum
import com.example.ui.theme.FrostedPurple
import com.example.ui.theme.FrostedTextMuted
import com.example.ui.theme.FrostedTextPrimary
import com.example.ui.theme.FrostedTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FrostedChatScreen(
    viewModel: CompanionViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current
    val personaSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val settingsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Auto-scroll when messages change or typing state updates
    LaunchedEffect(uiState.messages.size, uiState.isTyping) {
        if (uiState.messages.isNotEmpty()) {
            val targetIndex = if (uiState.isTyping) uiState.messages.size else uiState.messages.size - 1
            if (targetIndex >= 0 && targetIndex <= uiState.messages.size) {
                try {
                    listState.animateScrollToItem(targetIndex)
                } catch (_: Exception) {
                    listState.scrollToItem(targetIndex)
                }
            }
        }
    }

    FrostedGlassBackground(modifier = modifier) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // --- TOP FROSTED HEADER BAR ---
            val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x771C1B1F))
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0x1AFFFFFF))
                        ),
                        shape = RoundedCornerShape(0.dp)
                    )
                    .padding(top = statusBarPadding)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar & Info
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.togglePersonaMenu() }
                            .padding(4.dp)
                            .testTag("aria_header_info")
                    ) {
                        AriaAvatar(sizeDp = 42, initial = "A")

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Aria",
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "• " + uiState.selectedPersona.title,
                                    color = FrostedLilac.copy(alpha = 0.75f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            ActiveIndicator()
                        }
                    }

                    // Action Buttons (Persona, Settings, Speech toggle, Clear)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Persona toggle
                        IconButton(
                            onClick = { viewModel.togglePersonaMenu() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x14FFFFFF))
                                .border(1.dp, Color(0x20FFFFFF), CircleShape)
                                .testTag("persona_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Switch Persona",
                                tint = FrostedLilac,
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        // API Settings button
                        IconButton(
                            onClick = { viewModel.toggleSettings() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x14FFFFFF))
                                .border(1.dp, Color(0x20FFFFFF), CircleShape)
                                .testTag("settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "API Settings",
                                tint = FrostedLilacLight,
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        // Voice / TTS toggle
                        IconButton(
                            onClick = { viewModel.toggleTts() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (uiState.isTtsEnabled) FrostedPurple.copy(alpha = 0.6f) else Color(0x14FFFFFF)
                                )
                                .border(1.dp, Color(0x20FFFFFF), CircleShape)
                                .testTag("tts_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (uiState.isTtsEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                contentDescription = "Toggle Speech",
                                tint = if (uiState.isTtsEnabled) Color.White else FrostedLilac.copy(alpha = 0.6f),
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        // Clear Chat
                        IconButton(
                            onClick = { viewModel.clearChat() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x14FFFFFF))
                                .border(1.dp, Color(0x20FFFFFF), CircleShape)
                                .testTag("clear_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear Chat",
                                tint = FrostedTextSecondary,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }

            // --- CHAT MESSAGES AREA ---
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("chat_messages_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = uiState.messages,
                    key = { it.id }
                ) { message ->
                    if (message.isFromUser) {
                        UserMessageBubble(message = message)
                    } else {
                        AriaMessageBubble(
                            message = message,
                            onSpeak = { text -> viewModel.speakText(text) },
                            onCopy = { text ->
                                clipboardManager.setText(AnnotatedString(text))
                            }
                        )
                    }
                }

                if (uiState.isTyping) {
                    item(key = "typing_indicator") {
                        TypingDotsIndicator()
                    }
                }
            }

            // --- QUICK SUGGESTION PROMPTS ---
            val promptScrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(promptScrollState)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                defaultQuickPrompts.forEach { promptItem ->
                    FrostedSuggestionChip(
                        text = promptItem.label,
                        onClick = {
                            viewModel.sendPrompt(promptItem.promptText)
                        }
                    )
                }
            }

            // --- BOTTOM FROSTED INPUT BAR ---
            val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0x991C1B1F), Color(0xEE1C1B1F))
                        )
                    )
                    .padding(horizontal = 16.dp)
                    .padding(top = 8.dp, bottom = navBarPadding + 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp, CircleShape, spotColor = FrostedPurple.copy(alpha = 0.35f))
                        .clip(CircleShape)
                        .background(Color(0xE62B2930))
                        .border(1.dp, Color(0x26FFFFFF), CircleShape)
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Text Input
                    BasicTextField(
                        value = uiState.inputText,
                        onValueChange = { viewModel.onInputTextChange(it) },
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 16.dp, end = 8.dp)
                            .testTag("chat_input_field"),
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Normal
                        ),
                        cursorBrush = SolidColor(FrostedLilac),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (uiState.inputText.isNotBlank()) {
                                    viewModel.sendPrompt(uiState.inputText)
                                }
                            }
                        ),
                        singleLine = false,
                        maxLines = 4,
                        decorationBox = { innerTextField ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (uiState.inputText.isEmpty()) {
                                    Text(
                                        text = "Message Aria...",
                                        color = FrostedTextMuted,
                                        fontSize = 15.sp
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )

                    // Send Button
                    val isSendActive = uiState.inputText.isNotBlank() && !uiState.isTyping
                    IconButton(
                        onClick = {
                            if (isSendActive) {
                                viewModel.sendPrompt(uiState.inputText)
                            }
                        },
                        enabled = isSendActive,
                        modifier = Modifier
                            .size(42.dp)
                            .shadow(
                                elevation = if (isSendActive) 8.dp else 0.dp,
                                shape = CircleShape,
                                spotColor = FrostedLilac.copy(alpha = 0.5f)
                            )
                            .clip(CircleShape)
                            .background(
                                if (isSendActive) FrostedLilac else Color(0x33D0BCFF)
                            )
                            .testTag("send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send message",
                            tint = if (isSendActive) FrostedDeepPurple else FrostedLilac.copy(alpha = 0.4f),
                            modifier = Modifier
                                .size(18.dp)
                                .padding(start = 2.dp)
                        )
                    }
                }
            }
        }

        // --- PERSONA SELECTION SHEET ---
        if (uiState.isPersonaMenuOpen) {
            ModalBottomSheet(
                onDismissRequest = { viewModel.togglePersonaMenu() },
                sheetState = personaSheetState,
                containerColor = Color(0xF21C1B1F),
                contentColor = FrostedTextPrimary,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                dragHandle = {
                    Box(
                        modifier = Modifier
                            .padding(top = 12.dp, bottom = 8.dp)
                            .size(width = 36.dp, height = 4.dp)
                            .clip(CircleShape)
                            .background(Color(0x40FFFFFF))
                    )
                }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .padding(bottom = 32.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = FrostedLilac,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Choose Aria's Persona",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Text(
                        text = "Customize the mood, style, and tone of your companion.",
                        fontSize = 13.sp,
                        color = FrostedTextSecondary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    PersonaType.values().forEach { persona ->
                        val isSelected = uiState.selectedPersona == persona

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isSelected) FrostedPurple.copy(alpha = 0.45f) else Color(0x14FFFFFF)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) FrostedLilac.copy(alpha = 0.6f) else Color(0x1CFFFFFF),
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .clickable { viewModel.setPersona(persona) }
                                .padding(16.dp)
                                .testTag("persona_option_${persona.name}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = persona.title,
                                        color = if (isSelected) FrostedLilac else Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = persona.subtitle,
                                        color = FrostedTextSecondary,
                                        fontSize = 12.5.sp,
                                        lineHeight = 17.sp
                                    )
                                }

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(26.dp)
                                            .clip(CircleShape)
                                            .background(FrostedLilac),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = FrostedDeepPurple,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- API / SETTINGS MODAL SHEET ---
        if (uiState.isSettingsOpen) {
            ApiSettingsSheet(
                uiState = uiState,
                onDismiss = { viewModel.toggleSettings() },
                onSave = { key, model, temp -> viewModel.saveApiSettings(key, model, temp) },
                onReset = { viewModel.resetApiSettings() },
                onTestKey = { key, model -> viewModel.testApiKey(key, model) },
                sheetState = settingsSheetState
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiSettingsSheet(
    uiState: CompanionUiState,
    onDismiss: () -> Unit,
    onSave: (apiKey: String, model: String, temperature: Float) -> Unit,
    onReset: () -> Unit,
    onTestKey: (apiKey: String, model: String) -> Unit,
    sheetState: androidx.compose.material3.SheetState
) {
    var keyInput by remember { mutableStateOf(uiState.customApiKey) }
    var modelInput by remember { mutableStateOf(uiState.selectedModel) }
    var tempInput by remember { mutableFloatStateOf(uiState.temperature) }
    var isKeyVisible by remember { mutableStateOf(false) }

    val availableModels = listOf(
        Pair("gemini-3.5-flash", "Gemini 3.5 Flash (Fast & Recommended)"),
        Pair("gemini-3.1-pro-preview", "Gemini 3.1 Pro (Deep Nuance & Reasoning)"),
        Pair("gemini-3.1-flash-lite-preview", "Gemini 3.1 Flash Lite (Ultra Lightweight)")
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xF41C1B1F),
        contentColor = FrostedTextPrimary,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 12.dp, bottom = 8.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(Color(0x40FFFFFF))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 36.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = FrostedLilac,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "API & Model Settings",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Current Active Source Badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x14FFFFFF))
                    .border(1.dp, Color(0x1EFFFFFF), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                if (uiState.activeKeySource.contains("Offline")) FrostedTextSecondary else FrostedActiveGreen
                            )
                    )
                    Text(
                        text = "Active Engine:",
                        color = FrostedTextSecondary,
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = uiState.activeKeySource,
                    color = FrostedLilac,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // API Key Input Section
            Text(
                text = "Custom Gemini API Key",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = FrostedLilacLight
            )
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("api_key_input"),
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 14.sp
                        ),
                        cursorBrush = SolidColor(FrostedLilac),
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        decorationBox = { inner ->
                            if (keyInput.isEmpty()) {
                                Text(
                                    text = "Paste your AI Studio Gemini Key...",
                                    color = FrostedTextMuted,
                                    fontSize = 13.5.sp
                                )
                            }
                            inner()
                        }
                    )

                    IconButton(
                        onClick = { isKeyVisible = !isKeyVisible },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle key visibility",
                            tint = FrostedLilac.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Test Key Action
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onTestKey(keyInput, modelInput) },
                    enabled = !uiState.isTestingKey,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FrostedLilac),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("test_key_button")
                ) {
                    if (uiState.isTestingKey) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = FrostedLilac,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Verifying...", fontSize = 12.sp)
                    } else {
                        Text("Test Connection", fontSize = 12.sp)
                    }
                }

                if (keyInput.isNotBlank()) {
                    Text(
                        text = "Clear Key",
                        color = FrostedTextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clickable { keyInput = "" }
                            .padding(4.dp)
                    )
                }
            }

            // Test Status Result
            if (uiState.testStatus != null) {
                Spacer(modifier = Modifier.height(6.dp))
                val isSuccess = uiState.testStatus.contains("Connected") || uiState.testStatus.contains("Successful")
                Text(
                    text = uiState.testStatus,
                    color = if (isSuccess) FrostedActiveGreen else Color(0xFFFF8A80),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Model Selection Section
            Text(
                text = "Model Selection",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = FrostedLilacLight
            )
            Spacer(modifier = Modifier.height(6.dp))

            availableModels.forEach { (modelId, label) ->
                val isSelected = modelInput == modelId
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) FrostedPurple.copy(alpha = 0.5f) else Color(0x10FFFFFF))
                        .border(
                            1.dp,
                            if (isSelected) FrostedLilac.copy(alpha = 0.6f) else Color(0x1AFFFFFF),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { modelInput = modelId }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else FrostedTextSecondary,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                        )
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = FrostedLilac,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Temperature / Creativity Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Creativity & Temperature",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = FrostedLilacLight
                )
                Text(
                    text = String.format("%.2f", tempInput),
                    color = FrostedLilac,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Slider(
                value = tempInput,
                onValueChange = { tempInput = it },
                valueRange = 0.2f..1.0f,
                steps = 7,
                colors = SliderDefaults.colors(
                    thumbColor = FrostedLilac,
                    activeTrackColor = FrostedPurple,
                    inactiveTrackColor = Color(0x22FFFFFF)
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Security note
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x0EFFFFFF))
                    .padding(12.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = FrostedLilac.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Custom keys are stored strictly in private device storage. If no key is entered, Aria seamlessly uses project secrets or intelligent on-device dialogue.",
                    color = FrostedTextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Bottom Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onReset()
                        keyInput = ""
                        modelInput = "gemini-3.5-flash"
                        tempInput = 0.85f
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FrostedTextSecondary),
                    border = BorderStroke(1.dp, Color(0x28FFFFFF)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset", fontSize = 13.sp)
                }

                Button(
                    onClick = {
                        onSave(keyInput, modelInput, tempInput)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FrostedLilac,
                        contentColor = FrostedDeepPurple
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1.5f)
                        .testTag("save_settings_button")
                ) {
                    Text(
                        text = "Save Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp
                    )
                }
            }
        }
    }
}
