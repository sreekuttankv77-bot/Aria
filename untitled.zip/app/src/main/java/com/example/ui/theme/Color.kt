package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FrostedDarkBg = Color(0xFF1C1B1F)
val FrostedDarkSurface = Color(0xFF2B2930)
val FrostedGlassBackground = Color(0x331C1B1F)
val FrostedCardGlass = Color(0x1AFFFFFF)
val FrostedCardGlassBorder = Color(0x22FFFFFF)
val FrostedCardUser = Color(0xCC4F378B)
val FrostedCardUserBorder = Color(0x40D0BCFF)

val FrostedPurple = Color(0xFF4F378B)
val FrostedDeepPurple = Color(0xFF381E72)
val FrostedLilac = Color(0xFFD0BCFF)
val FrostedLilacLight = Color(0xFFEADDFF)
val FrostedPlum = Color(0xFF31111D)

val FrostedTextPrimary = Color(0xFFE6E1E5)
val FrostedTextSecondary = Color(0xFFCAC4D0)
val FrostedTextMuted = Color(0xFF938F99)
val FrostedActiveGreen = Color(0xFF4ADE80)
