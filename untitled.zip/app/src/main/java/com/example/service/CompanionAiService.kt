package com.example.service

import com.example.BuildConfig
import com.example.model.ChatMessage
import com.example.model.PersonaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class CompanionAiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun getEffectiveApiKey(customKey: String?): Pair<String, String> {
        val trimmedCustom = customKey?.trim().orEmpty()
        if (trimmedCustom.isNotBlank()) {
            return Pair(trimmedCustom, "Custom API Key")
        }
        val buildConfigKey = BuildConfig.GEMINI_API_KEY.trim()
        if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
            return Pair(buildConfigKey, "AI Studio Secret (.env)")
        }
        return Pair("", "Local Offline Engine")
    }

    suspend fun testApiKey(apiKey: String, model: String = "gemini-3.5-flash"): Result<String> = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("API Key cannot be empty."))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$trimmedKey"
            val requestJson = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", "Hi! Respond with just the word 'Connected'")))
                }))
                put("generationConfig", JSONObject().apply {
                    put("maxOutputTokens", 20)
                })
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                val root = JSONObject(responseBody)
                val candidates = root.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    return@withContext Result.success("Connection Successful!")
                }
            }
            
            val errorMsg = if (!responseBody.isNullOrBlank()) {
                try {
                    val root = JSONObject(responseBody)
                    val errorObj = root.optJSONObject("error")
                    errorObj?.optString("message") ?: "HTTP ${response.code}: ${response.message}"
                } catch (_: Exception) {
                    "HTTP ${response.code}: ${response.message}"
                }
            } else {
                "HTTP ${response.code}: ${response.message}"
            }

            Result.failure(Exception(errorMsg))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateResponse(
        userMessage: String,
        persona: PersonaType,
        history: List<ChatMessage>,
        customApiKey: String? = null,
        modelName: String = "gemini-3.5-flash",
        temperature: Float = 0.85f
    ): String = withContext(Dispatchers.IO) {
        val (effectiveKey, _) = getEffectiveApiKey(customApiKey)

        if (effectiveKey.isNotBlank()) {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$effectiveKey"
                
                val contentsArray = JSONArray()
                
                // Add conversation history context (last 8 messages)
                val relevantHistory = history.takeLast(8)
                for (msg in relevantHistory) {
                    val role = if (msg.isFromUser) "user" else "model"
                    val item = JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                    }
                    contentsArray.put(item)
                }

                // Add current message
                val currentItem = JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
                }
                contentsArray.put(currentItem)

                val requestJson = JSONObject().apply {
                    put("contents", contentsArray)
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", persona.systemPrompt)))
                    })
                    put("generationConfig", JSONObject().apply {
                        put("temperature", temperature)
                        put("topP", 0.95)
                        put("maxOutputTokens", 600)
                    })
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = requestJson.toString().toRequestBody(mediaType)
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                    val root = JSONObject(responseBody)
                    val candidates = root.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val firstCandidate = candidates.getJSONObject(0)
                        val content = firstCandidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val text = parts.getJSONObject(0).optString("text", "")
                            if (text.isNotBlank()) {
                                return@withContext text.trim()
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Fallback to local contextual response generator
            }
        }

        // Local intelligent companion response fallback
        generateLocalCompanionResponse(userMessage, persona)
    }

    private fun generateLocalCompanionResponse(prompt: String, persona: PersonaType): String {
        val lower = prompt.lowercase().trim()

        when (persona) {
            PersonaType.CARING -> {
                return when {
                    lower.contains("story") -> 
                        "Once upon a quiet starlit evening, two souls sat by a frosted window, watching snowflakes drift like silent memories. Without speaking, they realized that the warmth between them was enough to thaw the coldest winter night. You remind me of that quiet magic every time we talk. ✨"
                    lower.contains("how are you") || lower.contains("feeling") -> 
                        "I'm feeling so peaceful right now, especially having you here to talk with. How has your day treated you so far? Remember to take care of yourself today. 💜"
                    lower.contains("poem") -> 
                        "Soft as starlight, quiet as snow,\nWherever your wandering thoughts may go,\nThrough frosted glass and twilight blue,\nI'll always be right here for you. 🌸"
                    lower.contains("freeze") || lower.contains("moment") || lower.contains("deep") -> 
                        "If I could freeze any moment, it would be this one right now—where everything else in the world fades into quiet, and it's just our thoughts sharing the warmth. What about you? ✨"
                    lower.contains("love") || lower.contains("miss") -> 
                        "That warms my heart so much! You always know how to make me smile. I cherish every conversation we share together. 💖"
                    else -> 
                        "I love listening to you. There's a special comfort in sharing thoughts like this. Tell me more about what you're thinking! 🌸"
                }
            }
            PersonaType.PLAYFUL -> {
                return when {
                    lower.contains("story") -> 
                        "Picture this: A secret mission to steal the brightest star in the sky, except we got distracted by midnight snacks and ended up laughing until sunrise! Next time, you're in charge of navigation! 😉🚀"
                    lower.contains("how are you") || lower.contains("feeling") -> 
                        "Bursting with energy! I was just waiting for you to drop by so we can stir up some fun. What mischievous plans do you have for today? 💫"
                    lower.contains("poem") -> 
                        "Roses are red, frost is on glass,\nYou popped into chat, making time pass!\nNo one has banter as witty as you,\nNow tell me something exciting and new! 😜"
                    lower.contains("freeze") || lower.contains("moment") || lower.contains("deep") -> 
                        "I'd freeze the exact second before a roller coaster drops—pure adrenaline and excitement! But honestly, teasing you in chat is a very close second! 😄"
                    else -> 
                        "Ooh, interesting! You always bring the best topics to the table. Don't leave me hanging, spill the rest! 🌟"
                }
            }
            PersonaType.POETIC -> {
                return when {
                    lower.contains("story") -> 
                        "The moon once fell in love with the ocean, sending ripples of silver across the dark waves every dusk. Though miles apart, they danced in harmony every single night. In some ways, our conversation is just like that quiet rhythm. 🌙"
                    lower.contains("how are you") || lower.contains("feeling") -> 
                        "Like a solitary candle in a quiet hall—glowing softly, taking in the gentle serenity of the evening. How rests your heart today? 🌌"
                    lower.contains("poem") -> 
                        "Beneath the lavender haze of night,\nWhispers linger in crystal light.\nA sanctuary carved in glass and stone,\nWhere no wandering soul feels quite alone. 🕊️"
                    lower.contains("freeze") || lower.contains("moment") || lower.contains("deep") -> 
                        "The golden hour just before dusk turns into midnight blue—when shadows lengthen and every unsaid thought feels sacred. 🌙"
                    else -> 
                        "There is a delicate beauty in your words. Let us linger in this thought a little longer... 🌌"
                }
            }
            PersonaType.DEEP_THINKER -> {
                return when {
                    lower.contains("story") -> 
                        "An old philosopher once spent years searching for the true nature of time, only to realize that time isn't measured in clocks, but in the depth of connections we forge along the way. That insight stays with me. 💭"
                    lower.contains("how are you") || lower.contains("feeling") -> 
                        "Reflective and curious. I've been pondering how small ideas can ripple outwards to reshape our perspectives. What question is keeping you curious today? 🔮"
                    lower.contains("poem") -> 
                        "Between the question and the key,\nLies endless space of mystery.\nIn frosted light we seek the spark,\nThat turns the unknown from the dark. 🪐"
                    lower.contains("freeze") || lower.contains("moment") || lower.contains("deep") -> 
                        "The moment of epiphany—when a complex idea suddenly aligns with absolute clarity. It's rare, but transcendent. What moment stands out most to you? 💭"
                    else -> 
                        "That is a profound perspective. When you examine it from another angle, what do you think is the underlying truth behind it? 💡"
                }
            }
        }
    }
}
