package com.example.monacominigp

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.MotionEvent
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(245,245,242)))
        setContentView(GameView())
    }

    inner class GameView : View(this) {
        val p=Paint(Paint.ANTI_ALIAS_FLAG)
        var menu=true
        var carX=0.5f; var carY=0.68f; var speed=0f
        var lap=1; var boost=1f
        var left=false; var right=false
        val track=Path()

        override fun onDraw(c:Canvas) {
            val w=width.toFloat(); val h=height.toFloat()
            c.drawColor(Color.rgb(246,246,242))
            if(menu){ drawMenu(c,w,h); return }
            drawTrack(c,w,h); drawHud(c,w,h); drawCar(c,w,h)
        }

        fun rounded(c:Canvas,l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int){
            p.color=color; p.style=Paint.Style.FILL; c.drawRoundRect(l,t,r,b,rad,rad,p)
        }

        fun drawMenu(c:Canvas,w:Float,h:Float){
            p.textAlign=Paint.Align.CENTER; p.color=Color.rgb(25,25,25)
            p.typeface=Typeface.create("sans",Typeface.BOLD)
            p.textSize=min(w,h)*.09f; c.drawText("MONACO",w/2,h*.20f,p)
            p.textSize=min(w,h)*.045f; p.typeface=Typeface.create("sans",Typeface.NORMAL)
            c.drawText("MINI GP",w/2,h*.27f,p)
            p.textSize=min(w,h)*.12f; c.drawText("🏎",w/2,h*.48f,p)
            rounded(c,w*.38f,h*.58f,w*.62f,h*.72f,h*.07f,Color.rgb(30,30,30))
            p.color=Color.WHITE;p.textSize=min(w,h)*.045f;p.typeface=Typeface.DEFAULT_BOLD
            c.drawText("PLAY",w/2,h*.665f,p)
            p.color=Color.DKGRAY;p.typeface=Typeface.DEFAULT
            p.textSize=min(w,h)*.028f
            c.drawText("Offline • Arcade • Monaco",w/2,h*.84f,p)
        }

        fun drawTrack(c:Canvas,w:Float,h:Float){
            // Stylized Monaco-like winding street circuit for the prototype.
            track.reset()
            track.moveTo(w*.22f,h*.20f); track.cubicTo(w*.08f,h*.28f,w*.10f,h*.62f,w*.28f,h*.76f)
            track.cubicTo(w*.45f,h*.90f,w*.68f,h*.82f,w*.74f,h*.63f)
            track.cubicTo(w*.80f,h*.46f,w*.65f,h*.36f,w*.52f,h*.42f)
            track.cubicTo(w*.39f,h*.48f,w*.44f,h*.60f,w*.58f,h*.57f)
            p.style=Paint.Style.STROKE;p.strokeWidth=min(w,h)*.20f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.rgb(48,48,48);c.drawPath(track,p)
            p.strokeWidth=min(w,h)*.15f;p.color=Color.rgb(235,235,232);c.drawPath(track,p)
            p.strokeWidth=min(w,h)*.012f;p.color=Color.rgb(245,245,245);c.drawPath(track,p)
            p.style=Paint.Style.FILL
            // simple harbour/building shapes
            p.color=Color.rgb(205,225,231);c.drawRect(0f,0f,w*.17f,h,p)
            p.color=Color.rgb(224,214,196);c.drawRect(w*.83f,0f,w,h,p)
            p.color=Color.rgb(190,190,185)
            for(i in 0..7)c.drawRect(w*(.02f+i*.12f),h*.08f,w*(.07f+i*.12f),h*.14f,p)
        }

        fun drawHud(c:Canvas,w:Float,h:Float){
            rounded(c,w*.035f,h*.045f,w*.13f,h*.13f,h*.035f,Color.WHITE)
            rounded(c,w*.43f,h*.045f,w*.57f,h*.13f,h*.035f,Color.WHITE)
            rounded(c,w*.87f,h*.045f,w*.965f,h*.13f,h*.035f,Color.WHITE)
            p.color=Color.rgb(25,25,25);p.textAlign=Paint.Align.CENTER;p.typeface=Typeface.DEFAULT_BOLD
            p.textSize=h*.045f;c.drawText("P1",w*.082f,h*.105f,p)
            c.drawText("LAP $lap/3",w*.5f,h*.105f,p)
            c.drawText("01:18.42",w*.918f,h*.105f,p)
            rounded(c,w*.40f,h*.84f,w*.60f,h*.96f,h*.05f,Color.WHITE)
            p.color=Color.rgb(25,25,25);p.textSize=h*.035f;c.drawText("BOOST",w*.5f,h*.915f,p)
        }

        fun drawCar(c:Canvas,w:Float,h:Float){
            val x=carX*w; val y=carY*h
            p.color=Color.rgb(215,30,35);p.style=Paint.Style.FILL
            c.drawRoundRect(x-w*.018f,y-h*.045f,x+w*.018f,y+h*.045f,h*.018f,h*.018f,p)
            p.color=Color.WHITE;c.drawCircle(x,y-h*.025f,h*.008f,p)
            p.color=Color.rgb(20,20,20);c.drawRect(x-w*.026f,y-h*.035f,x-w*.018f,y+h*.035f,p);c.drawRect(x+w*.018f,y-h*.035f,x+w*.026f,y+h*.035f,p)
        }

        override fun onTouchEvent(e:MotionEvent):Boolean{
            val x=e.x; val y=e.y; val w=width.toFloat(); val h=height.toFloat()
            if(e.action==MotionEvent.ACTION_DOWN && menu){
                if(x>w*.35f && x<w*.65f && y>h*.54f && y<h*.76f){menu=false;invalidate();return true}
            }
            if(!menu){
                left=x<w*.28f && y>h*.72f
                right=x>w*.72f && y>h*.72f
                if(e.action==MotionEvent.ACTION_UP){left=false;right=false}
                if(left)carX=max(.15f,carX-.008f)
                if(right)carX=min(.85f,carX+.008f)
                carY-=.0012f
                if(carY<.18f){carY=.70f;lap++;if(lap>3)lap=1}
                invalidate()
            }
            return true
        }
    }
}
